"use client"

import  from "../assets/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}