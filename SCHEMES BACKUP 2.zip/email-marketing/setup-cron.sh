#!/bin/bash
# Setup cron job for automated email campaigns

# Add to crontab (run crontab -e and add this line):
# 0 9 * * 1 /usr/bin/php /path/to/your/website/email-marketing/schedule-campaign.php

echo "Setting up email marketing cron job..."
echo "Add this line to your crontab (run 'crontab -e'):"
echo "0 9 * * 1 /usr/bin/php $(pwd)/schedule-campaign.php"
echo ""
echo "This will send newsletters every Monday at 9 AM"