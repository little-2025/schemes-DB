<?php

function getSubscribers() {
    $subscribers = [];
    $csvFile = 'email.csv';
    
    if (($handle = fopen($csvFile, "r")) !== FALSE) {
        // Skip header row
        fgetcsv($handle);
        
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $subscribers[] = [
                'email' => $data[0],
                'name' => isset($data[1]) ? $data[1] : '',
                'subscription_date' => isset($data[2]) ? $data[2] : '',
                'preferences' => isset($data[3]) ? $data[3] : 'all'
            ];
        }
        fclose($handle);
    }
    
    return $subscribers;
}

function getRecentUploads() {
    // This would typically query your database
    // For demo purposes, returning sample data
    return [
        [
            'title' => 'Grade 5 Mathematics Lesson Plans - Term 1',
            'category' => 'lesson-plans',
            'category_name' => 'Lesson Plans',
            'upload_date' => '2024-01-15',
            'description' => 'Complete set of mathematics lesson plans for Grade 5, Term 1 covering all CBC learning areas.',
            'price' => 'KSh 500',
            'url' => 'https://www.schemes.co.ke/browse.php?category=lesson-plans&grade=5&subject=mathematics'
        ],
        [
            'title' => 'CBC Grade 4 Science Schemes of Work',
            'category' => 'schemes-of-work',
            'category_name' => 'Schemes of Work',
            'upload_date' => '2024-01-14',
            'description' => 'Comprehensive science schemes of work for Grade 4 aligned with CBC curriculum.',
            'price' => 'KSh 300',
            'url' => 'https://www.schemes.co.ke/browse.php?category=schemes-of-work&grade=4&subject=science'
        ],
        [
            'title' => 'KCSE Biology Revision Notes 2024',
            'category' => 'revision-materials',
            'category_name' => 'Revision Materials',
            'upload_date' => '2024-01-13',
            'description' => 'Updated KCSE Biology revision notes with past paper questions and answers.',
            'price' => 'KSh 400',
            'url' => 'https://www.schemes.co.ke/browse.php?category=revision-materials&level=kcse&subject=biology'
        ],
        [
            'title' => 'Grade 6 English Assessment Tools',
            'category' => 'assessment-tools',
            'category_name' => 'Assessment Tools',
            'upload_date' => '2024-01-12',
            'description' => 'Complete assessment package for Grade 6 English including rubrics and marking schemes.',
            'price' => 'KSh 350',
            'url' => 'https://www.schemes.co.ke/browse.php?category=assessment-tools&grade=6&subject=english'
        ],
        [
            'title' => 'Primary School Records of Work Templates',
            'category' => 'records-of-work',
            'category_name' => 'Records of Work',
            'upload_date' => '2024-01-11',
            'description' => 'Professional record keeping templates for all primary school subjects.',
            'price' => 'KSh 250',
            'url' => 'https://www.schemes.co.ke/browse.php?category=records-of-work&level=primary'
        ]
    ];
}

function getFeaturedCategories() {
    return [
        [
            'name' => 'Lesson Plans',
            'slug' => 'lesson-plans',
            'description' => 'Ready-to-use lesson plans for all subjects and grades',
            'icon' => '📚',
            'count' => '500+',
            'url' => 'https://www.schemes.co.ke/browse.php?category=lesson-plans',
            'color' => '#2d7d32'
        ],
        [
            'name' => 'Schemes of Work',
            'slug' => 'schemes-of-work',
            'description' => 'Comprehensive schemes covering entire terms',
            'icon' => '📋',
            'count' => '300+',
            'url' => 'https://www.schemes.co.ke/browse.php?category=schemes-of-work',
            'color' => '#388e3c'
        ],
        [
            'name' => 'Assessment Tools',
            'slug' => 'assessment-tools',
            'description' => 'Tests, exams, and evaluation materials',
            'icon' => '✅',
            'count' => '400+',
            'url' => 'https://www.schemes.co.ke/browse.php?category=assessment-tools',
            'color' => '#43a047'
        ],
        [
            'name' => 'Revision Materials',
            'slug' => 'revision-materials',
            'description' => 'KCPE and KCSE revision notes and materials',
            'icon' => '📖',
            'count' => '250+',
            'url' => 'https://www.schemes.co.ke/browse.php?category=revision-materials',
            'color' => '#4caf50'
        ]
    ];
}

function generateEmailContent($subscriber, $recentUploads, $featuredCategories) {
    $subscriberName = !empty($subscriber['name']) ? $subscriber['name'] : 'Valued Educator';
    
    ob_start();
    include 'email-template.php';
    return ob_get_clean();
}

function sendMarketingEmail($subscriber, $content, $config) {
    $to = $subscriber['email'];
    $subject = $config['subject'];
    
    $headers = [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        'From: ' . $config['from_name'] . ' <' . $config['from_email'] . '>',
        'Reply-To: ' . $config['reply_to'],
        'X-Mailer: PHP/' . phpversion(),
        'X-Priority: 3',
        'X-MSMail-Priority: Normal'
    ];
    
    return mail($to, $subject, $content, implode("\r\n", $headers));
}

function logEmailCampaign($sentCount, $failedCount) {
    $logEntry = [
        'date' => date('Y-m-d H:i:s'),
        'sent' => $sentCount,
        'failed' => $failedCount,
        'total' => $sentCount + $failedCount
    ];
    
    $logFile = 'campaign-log.json';
    $logs = [];
    
    if (file_exists($logFile)) {
        $logs = json_decode(file_get_contents($logFile), true) ?: [];
    }
    
    $logs[] = $logEntry;
    file_put_contents($logFile, json_encode($logs, JSON_PRETTY_PRINT));
}
?>