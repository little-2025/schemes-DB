<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Resources Available - Schemes.co.ke</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8f9fa;
        }
        
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        /* Header */
        .email-header {
            background: linear-gradient(135deg, #2d7d32, #4caf50);
            color: white;
            padding: 30px 20px;
            text-align: center;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .header-subtitle {
            font-size: 16px;
            opacity: 0.9;
        }
        
        /* Content sections */
        .email-content {
            padding: 0;
        }
        
        .section {
            padding: 30px 20px;
            border-bottom: 1px solid #eee;
        }
        
        .section:last-child {
            border-bottom: none;
        }
        
        .section-title {
            font-size: 24px;
            color: #2d7d32;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .greeting {
            font-size: 18px;
            color: #2d7d32;
            margin-bottom: 15px;
        }
        
        /* Recent uploads */
        .upload-item {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 4px solid #2d7d32;
            transition: transform 0.2s ease;
        }
        
        .upload-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .upload-title {
            font-size: 18px;
            font-weight: bold;
            color: #2d7d32;
            margin-bottom: 8px;
        }
        
        .upload-meta {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .upload-description {
            color: #555;
            margin-bottom: 15px;
        }
        
        .upload-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .price-tag {
            background: #4caf50;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .view-btn {
            background: #2d7d32;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s ease;
        }
        
        .view-btn:hover {
            background: #1b5e20;
        }
        
        /* Categories grid */
        .categories-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .category-card {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .category-card:hover {
            border-color: #4caf50;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        }
        
        .category-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }
        
        .category-name {
            font-size: 18px;
            font-weight: bold;
            color: #2d7d32;
            margin-bottom: 8px;
        }
        
        .category-description {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .category-count {
            font-size: 12px;
            color: #4caf50;
            font-weight: bold;
        }
        
        .category-link {
            display: inline-block;
            margin-top: 15px;
            background: #4caf50;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        
        .category-link:hover {
            background: #388e3c;
        }
        
        /* CTA Section */
        .cta-section {
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            text-align: center;
        }
        
        .cta-title {
            font-size: 24px;
            color: #2d7d32;
            margin-bottom: 15px;
        }
        
        .cta-text {
            font-size: 16px;
            color: #555;
            margin-bottom: 25px;
        }
        
        .cta-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .cta-btn {
            background: #2d7d32;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .cta-btn:hover {
            background: #1b5e20;
            transform: translateY(-2px);
        }
        
        .cta-btn.secondary {
            background: transparent;
            color: #2d7d32;
            border: 2px solid #2d7d32;
        }
        
        .cta-btn.secondary:hover {
            background: #2d7d32;
            color: white;
        }
        
        /* Footer */
        .email-footer {
            background: #2d7d32;
            color: white;
            padding: 30px 20px;
            text-align: center;
        }
        
        .footer-content {
            margin-bottom: 20px;
        }
        
        .contact-info {
            margin-bottom: 15px;
        }
        
        .contact-info p {
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .social-links {
            margin: 20px 0;
        }
        
        .social-links a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            font-size: 14px;
        }
        
        .unsubscribe {
            font-size: 12px;
            opacity: 0.8;
            margin-top: 20px;
        }
        
        .unsubscribe a {
            color: #81c784;
            text-decoration: none;
        }
        
        /* Mobile responsive */
        @media (max-width: 600px) {
            .email-container {
                margin: 0;
                box-shadow: none;
            }
            
            .section {
                padding: 20px 15px;
            }
            
            .email-header {
                padding: 20px 15px;
            }
            
            .logo {
                font-size: 24px;
            }
            
            .section-title {
                font-size: 20px;
            }
            
            .categories-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .upload-footer {
                flex-direction: column;
                align-items: stretch;
            }
            
            .view-btn {
                text-align: center;
            }
            
            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .cta-btn {
                width: 200px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <!-- Header -->
        <div class="email-header">
            <div class="logo">📚 Schemes.co.ke</div>
            <div class="header-subtitle">Quality Educational Resources for Kenyan Educators</div>
        </div>
        
        <!-- Email Content -->
        <div class="email-content">
            <!-- Greeting Section -->
            <div class="section">
                <div class="greeting">Hello <?= htmlspecialchars($subscriberName) ?>! 👋</div>
                <p>We hope this email finds you well and thriving in your educational journey. We're excited to share some fantastic new resources that have just been added to our platform!</p>
            </div>
            
            <!-- Recent Uploads Section -->
            <div class="section">
                <h2 class="section-title">🆕 Recently Added Resources</h2>
                
                <?php foreach (array_slice($recentUploads, 0, 3) as $upload): ?>
                <div class="upload-item">
                    <div class="upload-title"><?= htmlspecialchars($upload['title']) ?></div>
                    <div class="upload-meta">
                        📂 <?= htmlspecialchars($upload['category_name']) ?> • 
                        📅 Added on <?= date('M j, Y', strtotime($upload['upload_date'])) ?>
                    </div>
                    <div class="upload-description"><?= htmlspecialchars($upload['description']) ?></div>
                    <div class="upload-footer">
                        <span class="price-tag"><?= htmlspecialchars($upload['price']) ?></span>
                        <a href="<?= htmlspecialchars($upload['url']) ?>" class="view-btn">View Resource</a>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <div style="text-align: center; margin-top: 20px;">
                    <a href="https://www.schemes.co.ke/browse.php?sort=newest" class="view-btn">View All New Resources</a>
                </div>
            </div>
            
            <!-- Featured Categories Section -->
            <div class="section">
                <h2 class="section-title">📚 Explore Our Categories</h2>
                <p style="text-align: center; margin-bottom: 20px;">Discover comprehensive educational materials across all subjects and grade levels</p>
                
                <div class="categories-grid">
                    <?php foreach ($featuredCategories as $category): ?>
                    <div class="category-card">
                        <div class="category-icon"><?= $category['icon'] ?></div>
                        <div class="category-name"><?= htmlspecialchars($category['name']) ?></div>
                        <div class="category-description"><?= htmlspecialchars($category['description']) ?></div>
                        <div class="category-count"><?= htmlspecialchars($category['count']) ?> Resources</div>
                        <a href="<?= htmlspecialchars($category['url']) ?>" class="category-link">Browse <?= htmlspecialchars($category['name']) ?></a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Special Offers Section -->
            <div class="section">
                <h2 class="section-title">🎯 This Week's Highlights</h2>
                <div style="background: #fff3e0; padding: 20px; border-radius: 10px; border-left: 4px solid #ff9800;">
                    <h3 style="color: #e65100; margin-bottom: 10px;">💡 Did You Know?</h3>
                    <p>Our resources are created by experienced Kenyan educators and are fully aligned with the CBC curriculum. Each resource undergoes quality review to ensure it meets the highest educational standards.</p>
                </div>
                
                <div style="background: #e8f5e9; padding: 20px; border-radius: 10px; border-left: 4px solid #4caf50; margin-top: 15px;">
                    <h3 style="color: #2d7d32; margin-bottom: 10px;">🚀 Quick Access Tips</h3>
                    <ul style="margin-left: 20px; color: #555;">
                        <li>Use our search filters to find resources by grade, subject, or term</li>
                        <li>Download resources instantly after purchase</li>
                        <li>Access your purchased materials anytime from your account</li>
                        <li>Contact our support team for any assistance</li>
                    </ul>
                </div>
            </div>
            
            <!-- Call to Action Section -->
            <div class="section cta-section">
                <h2 class="cta-title">Ready to Enhance Your Teaching?</h2>
                <p class="cta-text">Join thousands of educators who trust Schemes.co.ke for their teaching resources</p>
                <div class="cta-buttons">
                    <a href="https://www.schemes.co.ke/browse.php" class="cta-btn">Browse All Resources</a>
                    <a href="https://www.schemes.co.ke/contact.php" class="cta-btn secondary">Contact Support</a>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="email-footer">
            <div class="footer-content">
                <div class="contact-info">
                    <p><strong>📞 Phone:</strong> +254 710 178 7242</p>
                    <p><strong>📧 Email:</strong> info@schemes.co.ke</p>
                    <p><strong>💳 M-Pesa Till:</strong> 5272865</p>
                </div>
                
                <div class="social-links">
                    <a href="https://www.schemes.co.ke">🌐 Website</a>
                    <a href="https://www.schemes.co.ke/about.php">ℹ️ About Us</a>
                    <a href="https://www.schemes.co.ke/contact.php">📞 Contact</a>
                </div>
                
                <p style="font-size: 14px; margin-top: 15px;">
                    <strong>Schemes.co.ke</strong> - Empowering Education in Kenya<br>
                    Your trusted source for quality educational resources
                </p>
            </div>
            
            <div class="unsubscribe">
                <p>You're receiving this email because you subscribed to our newsletter.</p>
                <p><a href="https://www.schemes.co.ke/unsubscribe.php?email=<?= urlencode($subscriber['email']) ?>">Unsubscribe</a> | <a href="https://www.schemes.co.ke/preferences.php?email=<?= urlencode($subscriber['email']) ?>">Update Preferences</a></p>
            </div>
        </div>
    </div>
</body>
</html>