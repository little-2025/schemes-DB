<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

$message = '';
$email = isset($_GET['email']) ? $_GET['email'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $reason = $_POST['reason'] ?? '';
    
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Remove from email list
        if (removeFromEmailList($email)) {
            // Log unsubscribe
            logUnsubscribe($email, $reason);
            $message = "You have been successfully unsubscribed from our mailing list.";
        } else {
            $message = "Email address not found in our system.";
        }
    } else {
        $message = "Please enter a valid email address.";
    }
}

function removeFromEmailList($email) {
    $csvFile = 'email.csv';
    $tempFile = 'temp_email.csv';
    $found = false;
    
    if (($readHandle = fopen($csvFile, "r")) !== FALSE) {
        if (($writeHandle = fopen($tempFile, "w")) !== FALSE) {
            // Copy header
            $header = fgetcsv($readHandle);
            fputcsv($writeHandle, $header);
            
            // Copy all rows except the one to remove
            while (($data = fgetcsv($readHandle)) !== FALSE) {
                if ($data[0] !== $email) {
                    fputcsv($writeHandle, $data);
                } else {
                    $found = true;
                }
            }
            
            fclose($writeHandle);
        }
        fclose($readHandle);
        
        if ($found) {
            rename($tempFile, $csvFile);
        } else {
            unlink($tempFile);
        }
    }
    
    return $found;
}

function logUnsubscribe($email, $reason) {
    $logEntry = [
        'email' => $email,
        'date' => date('Y-m-d H:i:s'),
        'reason' => $reason
    ];
    
    $logFile = 'unsubscribe-log.json';
    $logs = [];
    
    if (file_exists($logFile)) {
        $logs = json_decode(file_get_contents($logFile), true) ?: [];
    }
    
    $logs[] = $logEntry;
    file_put_contents($logFile, json_encode($logs, JSON_PRETTY_PRINT));
}

include '../includes/header.php';
?>

<div class="container" style="max-width: 600px; margin: 50px auto; padding: 20px;">
    <div class="card">
        <div class="card-header" style="background: #2d7d32; color: white; text-align: center; padding: 20px;">
            <h2>Unsubscribe from Schemes.co.ke Newsletter</h2>
        </div>
        <div class="card-body" style="padding: 30px;">
            <?php if ($message): ?>
                <div class="alert alert-info" style="background: #e8f5e9; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>
            
            <?php if (!$message || strpos($message, 'successfully') === false): ?>
            <form method="POST">
                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="email" style="font-weight: bold; margin-bottom: 5px; display: block;">Email Address:</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" 
                           required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                </div>
                
                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="reason" style="font-weight: bold; margin-bottom: 5px; display: block;">Reason for unsubscribing (optional):</label>
                    <select name="reason" id="reason" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                        <option value="">Select a reason...</option>
                        <option value="too_frequent">Emails too frequent</option>
                        <option value="not_relevant">Content not relevant</option>
                        <option value="no_longer_teaching">No longer teaching</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <button type="submit" style="background: #2d7d32; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">
                    Unsubscribe
                </button>
            </form>
            <?php else: ?>
                <div style="text-align: center;">
                    <a href="https://www.schemes.co.ke" style="background: #2d7d32; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px;">
                        Return to Website
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>