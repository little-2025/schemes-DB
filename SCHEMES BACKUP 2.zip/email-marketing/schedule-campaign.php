<?php
require_once '../includes/config.php';
require_once 'email-functions.php';

// This script can be run via cron job for automated campaigns
// Example cron: 0 9 * * 1 /usr/bin/php /path/to/schedule-campaign.php

$today = date('N'); // 1 = Monday, 7 = Sunday

// Send newsletter every Monday
if ($today == 1) {
    echo "Starting weekly newsletter campaign...\n";
    include 'send-newsletter.php';
}

// Send special campaigns on specific dates
$currentDate = date('Y-m-d');
$specialCampaigns = [
    '2024-02-01' => 'february-special.php',
    '2024-03-01' => 'march-special.php',
    // Add more special campaign dates
];

if (isset($specialCampaigns[$currentDate])) {
    echo "Starting special campaign for $currentDate...\n";
    include $specialCampaigns[$currentDate];
}
?>