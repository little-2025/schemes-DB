<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once 'email-functions.php';

// Set execution time limit for bulk emails
set_time_limit(300);

// Get recent uploads or featured content
$recentUploads = getRecentUploads();
$featuredCategories = getFeaturedCategories();
$subscribers = getSubscribers();

// Email configuration
$emailConfig = [
    'subject' => 'New Educational Resources Available - Schemes.co.ke',
    'from_name' => 'Schemes.co.ke Team',
    'from_email' => 'info@schemes.co.ke',
    'reply_to' => 'support@schemes.co.ke'
];

// Send emails
$sentCount = 0;
$failedCount = 0;

foreach ($subscribers as $subscriber) {
    $emailContent = generateEmailContent($subscriber, $recentUploads, $featuredCategories);
    
    if (sendMarketingEmail($subscriber, $emailContent, $emailConfig)) {
        $sentCount++;
        echo "✓ Email sent to: " . $subscriber['email'] . "\n";
    } else {
        $failedCount++;
        echo "✗ Failed to send to: " . $subscriber['email'] . "\n";
    }
    
    // Add small delay to prevent overwhelming the mail server
    usleep(100000); // 0.1 second delay
}

echo "\n=== Email Campaign Summary ===\n";
echo "Total emails sent: $sentCount\n";
echo "Failed emails: $failedCount\n";
echo "Campaign completed at: " . date('Y-m-d H:i:s') . "\n";

// Log the campaign
logEmailCampaign($sentCount, $failedCount);
?>