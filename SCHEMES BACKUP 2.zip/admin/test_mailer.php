<?php
require_once '../includes/mailer_config.php';

$mail = setupMailer();
$mail->addAddress('youremail@example.com');
$mail->Subject = 'Test Email';
$mail->Body = 'This is a test email from PHPMailer.';
if ($mail->send()) {
    echo "Email sent!";
} else {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
?>
