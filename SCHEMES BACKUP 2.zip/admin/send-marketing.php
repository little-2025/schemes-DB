<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once 'email_template.php'; // Template above

$emails_file = DATA_DIR . 'emails.csv';
$documents_file = DATA_DIR . 'documents.csv';

$subscribers = [];
$documents = [];

// Load emails
if (file_exists($emails_file)) {
    $handle = fopen($emails_file, 'r');
    while (($row = fgetcsv($handle)) !== false) {
        $subscribers[] = $row[0]; // Email only
    }
    fclose($handle);
}

// Load documents
if (file_exists($documents_file)) {
    $handle = fopen($documents_file, 'r');
    while (($row = fgetcsv($handle)) !== false) {
        $documents[] = [
            'filename' => $row[0] ?? '',
            'category' => $row[1] ?? '',
        ];
    }
    fclose($handle);
}

// Group documents by category
$groupedDocs = [];
foreach ($documents as $doc) {
    $groupedDocs[$doc['category']][] = $doc;
}

// Select random 1–2 documents per category
$randomPicks = [];
foreach ($groupedDocs as $category => $docs) {
    shuffle($docs);
    $randomPicks[$category] = array_slice($docs, 0, 2);
}

// Send emails
foreach ($subscribers as $email) {
    $to = $email;
    $subject = "Recommended Resources from Schemes.co.ke";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: Schemes.co.ke <" . SITE_EMAIL . ">\r\n";

    $message = generateEmailBody($email, $randomPicks);

    mail($to, $subject, $message, $headers);
}

echo "Emails sent successfully.";
?>
