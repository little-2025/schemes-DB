<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Manage Categories';
$success = '';
$error = '';

// Handle category addition
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'add' && verify_csrf($_POST['csrf_token'] ?? '')) {
    $title = trim($_POST['title'] ?? '');
    $parent_id = intval($_POST['parent_id'] ?? 0);
    $icon = trim($_POST['icon'] ?? '');

    if (empty($title)) {
        $error = 'Category title is required';
    } else {
        $categories = csv_to_array(DATA_DIR . 'categories.csv');
        $new_id = count($categories) + 1;
        $slug = slugify($title);

        // Check for duplicate slug
        $slug_exists = false;
        foreach ($categories as $cat) {
            if (($cat['slug'] ?? '') === $slug) {
                $slug_exists = true;
                break;
            }
        }

        if ($slug_exists) {
            $slug .= '-' . $new_id;
        }

        $new_category = [
            'id' => $new_id,
            'slug' => $slug,
            'title' => $title,
            'parent_id' => $parent_id,
            'icon' => $icon ?: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2v11z"/></svg>',
            'ordinal' => $new_id
        ];

        $categories[] = $new_category;
        save_categories_csv($categories);

        // Clear cache
        $cache_file = CACHE_DIR . 'csv_' . md5(DATA_DIR . 'categories.csv') . '.json';
        if (file_exists($cache_file)) {
            unlink($cache_file);
        }

        $success = 'Category added successfully!';
        $_POST = [];
    }
}

// Handle category deletion
if (isset($_GET['delete']) && verify_csrf($_GET['token'] ?? '')) {
    $cat_id = intval($_GET['delete']);
    $categories = csv_to_array(DATA_DIR . 'categories.csv');
    $documents = csv_to_array(DATA_DIR . 'documents.csv');

    // Check if category has documents
    $has_documents = false;
    foreach ($documents as $doc) {
        if (($doc['category_id'] ?? '') == $cat_id) {
            $has_documents = true;
            break;
        }
    }

    if ($has_documents) {
        $error = 'Cannot delete category that contains documents. Please move or delete the documents first.';
    } else {
        // Remove category
        foreach ($categories as $index => $cat) {
            if (($cat['id'] ?? '') == $cat_id) {
                unset($categories[$index]);
                break;
            }
        }

        $categories = array_values($categories);
        save_categories_csv($categories);

        // Clear cache
        $cache_file = CACHE_DIR . 'csv_' . md5(DATA_DIR . 'categories.csv') . '.json';
        if (file_exists($cache_file)) {
            unlink($cache_file);
        }

        $success = 'Category deleted successfully!';
    }
}

// Get categories
$categories = csv_to_array(DATA_DIR . 'categories.csv');
$documents = csv_to_array(DATA_DIR . 'documents.csv');

// Count documents per category
$doc_counts = [];
foreach ($documents as $doc) {
    $cat_id = $doc['category_id'] ?? '';
    if ($cat_id) {
        $doc_counts[$cat_id] = ($doc_counts[$cat_id] ?? 0) + 1;
    }
}

// Sort categories by ordinal safely
usort($categories, function($a, $b) {
    return intval($a['ordinal'] ?? 0) - intval($b['ordinal'] ?? 0);
});

include 'header.php';
?>

<div class="admin-content">
    <div class="page-header">
        <h1>Manage Categories</h1>
        <p>Organize your educational content structure</p>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?php echo e($success); ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-error">
        <?php echo e($error); ?>
    </div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 1fr 400px; gap: 2rem;">
        <!-- Categories List -->
        <div>
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Slug</th>
                            <th>Parent</th>
                            <th>Documents</th>
                            <th>Order</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $category): ?>
                        <?php 
                        $parent_title = '';
                        if (($category['parent_id'] ?? '0') != '0') {
                            foreach ($categories as $parent) {
                                if (($parent['id'] ?? '') == ($category['parent_id'] ?? '')) {
                                    $parent_title = $parent['title'] ?? '';
                                    break;
                                }
                            }
                        }
                        ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <div style="width: 32px; height: 32px; background: #e7f9f4; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
                                        <?php echo $category['icon'] ?? '<i class="fas fa-folder"></i>'; ?>
                                    </div>
                                    <div>
                                        <strong><?php echo e($category['title'] ?? 'Untitled'); ?></strong>
                                        <?php if (($category['parent_id'] ?? '0') != '0'): ?>
                                        <br><small style="color: #6b7280;">Subcategory</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><code><?php echo e($category['slug'] ?? ''); ?></code></td>
                            <td><?php echo $parent_title ? e($parent_title) : '<em>Root</em>'; ?></td>
                            <td>
                                <span style="font-weight: 600; color: #047857;">
                                    <?php echo $doc_counts[$category['id']] ?? 0; ?>
                                </span>
                            </td>
                            <td><?php echo e($category['ordinal'] ?? '0'); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="../category.php?cat=<?php echo e($category['slug'] ?? ''); ?>" class="btn btn-sm btn-outline" target="_blank" title="View">
                                        <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                            <circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </a>
                                    <?php if (($doc_counts[$category['id']] ?? 0) == 0): ?>
                                    <a href="?delete=<?php echo e($category['id'] ?? ''); ?>&token=<?php echo csrf_token(); ?>"
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Are you sure you want to delete this category?')"
                                       title="Delete">
                                        <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="3,6 5,6 21,6"/>
                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                        </svg>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Add Category Form -->
        <div>
            <div style="background: #ffffff; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                <h3 style="margin-bottom: 1.5rem;">Add New Category</h3>

                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">

                    <div class="form-group">
                        <label for="title">Category Title *</label>
                        <input type="text" id="title" name="title" required value="<?php echo e($_POST['title'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="parent_id">Parent Category</label>
                        <select id="parent_id" name="parent_id">
                            <option value="0">Root Category</option>
                            <?php foreach ($categories as $category): ?>
                            <?php if (($category['parent_id'] ?? '0') == '0'): ?>
                            <option value="<?php echo e($category['id'] ?? ''); ?>" <?php echo ($_POST['parent_id'] ?? '') == ($category['id'] ?? '') ? 'selected' : ''; ?>>
                                <?php echo e($category['title'] ?? ''); ?>
                            </option>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="icon">Icon SVG (optional)</label>
                        <textarea id="icon" name="icon" rows="3" placeholder="<svg>...</svg>"><?php echo e($_POST['icon'] ?? ''); ?></textarea>
                        <small>Paste SVG code for custom icon, or leave blank for default folder icon</small>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%;">Add Category</button>
                </form>
            </div>

            <!-- Category Statistics -->
            <div style="background: #ffffff; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); margin-top: 1.5rem;">
                <h4 style="margin-bottom: 1rem;">Statistics</h4>
                <div style="display: grid; gap: 1rem;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Total Categories:</span>
                        <strong><?php echo count($categories); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Root Categories:</span>
                        <strong><?php echo count(array_filter($categories, fn($cat) => ($cat['parent_id'] ?? '0') == '0')); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Subcategories:</span>
                        <strong><?php echo count(array_filter($categories, fn($cat) => ($cat['parent_id'] ?? '0') != '0')); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Total Documents:</span>
                        <strong><?php echo count($documents); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
if (!function_exists('save_categories_csv')) {
    function save_categories_csv($categories) {
        $file = DATA_DIR . 'categories.csv';
        $handle = fopen($file, 'w');
        if (!empty($categories)) {
            fputcsv($handle, array_keys($categories[0]));
            foreach ($categories as $category) {
                fputcsv($handle, $category);
            }
        }
        fclose($handle);
    }
}
?>

<?php include 'footer.php'; ?>
