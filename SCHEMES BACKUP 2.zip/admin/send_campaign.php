<?php
require_once('../includes/config.php');
require_once('../includes/PHPMailer/PHPMailer.php');
require_once('../includes/PHPMailer/SMTP.php');
require_once('../includes/PHPMailer/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmail($to, $subject, $body, $from = SITE_EMAIL, $fromName = SITE_NAME) {
    $mail = new PHPMailer(true);

    try {
        // SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.yourdomain.com';     // Replace with your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = 'your_smtp_user@yourdomain.com';  // Your SMTP username
        $mail->Password = 'your_smtp_password';             // Your SMTP password
        $mail->SMTPSecure = 'tls';                          // or 'ssl'
        $mail->Port = 587;                                  // or 465 for SSL

        $mail->setFrom($from, $fromName);
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return 'Mailer Error: ' . $mail->ErrorInfo;
    }
}

// Load emails
$emailsFile = '../data/emails.csv';
$emails = [];
if (($handle = fopen($emailsFile, 'r')) !== false) {
    while (($data = fgetcsv($handle)) !== false) {
        if (filter_var($data[0], FILTER_VALIDATE_EMAIL)) {
            $emails[] = $data[0];
        }
    }
    fclose($handle);
}

// Load email content
$subject = $_POST['subject'] ?? 'Schemes.co.ke Educational Resources';
$schedule = $_POST['schedule_time'] ?? null;
$now = date('Y-m-d H:i');
$logFile = '../data/campaign_log.csv';

ob_start(); // buffer log output
echo "<h2>Sending Campaign...</h2>";

foreach ($emails as $email) {
    if ($schedule && $schedule > $now) {
        echo "<p><b>$email:</b> Scheduled for later ($schedule)</p>";
        // Store for scheduled processing
        $scheduled[] = [$email, $subject, $schedule];
        continue;
    }

    $unsubscribeLink = SITE_URL . "/unsubscribe.php?email=" . urlencode($email);
    $body = file_get_contents('../templates/email_template.html');
    $body = str_replace('{{unsubscribe}}', $unsubscribeLink, $body);

    $result = sendEmail($email, $subject, $body);
    if ($result === true) {
        echo "<p><b>$email:</b> ✅ Sent successfully</p>";
    } else {
        echo "<p><b>$email:</b> ❌ Failed - $result</p>";
    }

    // Log
    $logEntry = [$email, date('Y-m-d H:i:s'), ($result === true) ? 'Sent' : 'Failed'];
    file_put_contents($logFile, implode(',', $logEntry) . "\n", FILE_APPEND);
}

// Save scheduled emails
if (!empty($scheduled)) {
    $file = fopen('../data/scheduled_campaigns.csv', 'a');
    foreach ($scheduled as $s) {
        fputcsv($file, $s);
    }
    fclose($file);
    echo "<p>⏰ Scheduled " . count($scheduled) . " emails for later sending.</p>";
}

$logOutput = ob_get_clean();
echo "<div style='padding: 20px; font-family: sans-serif;'>$logOutput</div>";
