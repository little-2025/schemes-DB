<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!is_admin()) {
    header('Location: login.php');
    exit;
}

$page_title = 'View Emails';
$emails_file = DATA_DIR . 'emails.csv';
$emails       = [];

/* ---------- 1. EXPORT HANDLERS ---------------- */
if (isset($_GET['export'])) {
    $exportType = $_GET['export'];

    // If the CSV doesn't exist, bail early
    if (!file_exists($emails_file)) {
        header('HTTP/1.0 404 Not Found');
        exit('No email entries found.');
    }

    // Common headers
    $now = gmdate('Y-m-d_H-i-s');
    $basename = 'emails_' . $now;

    switch ($exportType) {
        /* --- Export Raw CSV -------------------------------- */
        case 'csv':
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $basename . '.csv"');
            readfile($emails_file);
            exit;

        /* --- Export as “Excel” (CSV with Excel MIME‑type) -- */
        case 'excel':
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="' . $basename . '.xls"');
            readfile($emails_file);
            exit;
    }
}
/* ---------- 2. NORMAL PAGE RENDER ---------------- */
if (file_exists($emails_file)) {
    if (($handle = fopen($emails_file, 'r')) !== false) {
        while (($row = fgetcsv($handle)) !== false) {
            $emails[] = $row;
        }
        fclose($handle);
    }
}

include 'header.php';
?>

<div class="admin-content">
    <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;">
        <div>
            <h1>Collected Emails</h1>
            <p>List of emails submitted during downloads</p>
        </div>

        <?php if (!empty($emails)): ?>
        <div>
            <!-- Export buttons -->
            <a href="?export=csv"   class="btn btn-sm btn-outline" style="margin-right:6px;">Export CSV</a>
            <a href="?export=excel" class="btn btn-sm btn-primary">Export Excel</a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (empty($emails)): ?>
        <div class="alert alert-error">No email entries found yet.</div>
    <?php else: ?>
        <div class="table-container" style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Document</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($emails as $row): ?>
                        <tr>
                            <td><?php echo e($row[0] ?? ''); ?></td>
                            <td><?php echo e($row[1] ?? ''); ?></td>
                            <td><?php echo e($row[2] ?? ''); ?></td>
                            <td><?php echo e($row[3] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

