<?php
// process_scheduled_campaigns.php

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/mailer.php'; // your PHPMailer wrapper

define('SCHEDULED_CAMPAIGNS_CSV', DATA_DIR . 'scheduled_campaigns.csv');
define('CAMPAIGN_HISTORY_CSV', DATA_DIR . 'campaign_history.csv');

$admin_email = SITE_EMAIL;
$now = date('Y-m-d H:i:s');
$summary = [];

$scheduled = readCSV(SCHEDULED_CAMPAIGNS_CSV);
$remaining = [];
$executed_count = 0;

foreach ($scheduled as $row) {
    $category = $row['category'] ?? '';
    $subject = $row['subject'] ?? '';
    $body = $row['body'] ?? '';
    $schedule_time = $row['schedule_time'] ?? '';
    $campaign_id = $row['campaign_id'] ?? uniqid('camp_');

    if (empty($category) || strtotime($schedule_time) > time()) {
        $remaining[] = $row;
        continue;
    }

    $emails = getEmailsByCategory($category);
    $log = [];
    $sent = 0;
    $failed = 0;

    foreach ($emails as $email) {
        $email = trim($email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) continue;

        $personalized_body = str_replace('user@example.com', $email, $body);
        $status = sendMail($email, $subject, $personalized_body)
            ? 'Success'
            : 'Failed';

        if ($status === 'Failed') {
            sleep(1); // wait briefly before retry
            $status = sendMail($email, $subject, $personalized_body)
                ? 'Retried-Success'
                : 'Retried-Failed';
        }

        $log[] = [
            'timestamp' => $now,
            'campaign_id' => $campaign_id,
            'email' => $email,
            'status' => $status
        ];

        $status === 'Success' || $status === 'Retried-Success' ? $sent++ : $failed++;
    }

    $executed_count++;
    $summary[] = [
        'Time' => $now,
        'Campaign' => $subject,
        'Category' => $category,
        'Sent' => $sent,
        'Failed' => $failed
    ];

    // Append logs
    appendCSV(DATA_DIR . "campaign_logs/{$campaign_id}.csv", $log);
    appendCSV(CAMPAIGN_HISTORY_CSV, [[
        'timestamp' => $now,
        'campaign_id' => $campaign_id,
        'subject' => $subject,
        'category' => $category,
        'sent' => $sent,
        'failed' => $failed
    ]]);
}

// Save any remaining (future) campaigns
writeCSV(SCHEDULED_CAMPAIGNS_CSV, $remaining);

// Display summary
echo "<h2>Processed {$executed_count} scheduled campaign(s)</h2>";
foreach ($summary as $sum) {
    echo "<div style='margin-bottom:10px; padding:10px; border:1px solid #ccc;'>
        <strong>{$sum['Campaign']}</strong><br>
        Category: {$sum['Category']}<br>
        Sent: {$sum['Sent']}, Failed: {$sum['Failed']}<br>
        Time: {$sum['Time']}
    </div>";
}
?>
