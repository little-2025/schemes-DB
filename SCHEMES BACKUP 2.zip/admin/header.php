<?php
if (!is_admin()) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? e($page_title) . ' - ' : ''; ?>Admin - <?php echo SITE_NAME; ?></title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="../assets/admin.css">
</head>
<body class="admin-body">
    <!-- Admin Header -->
    <header class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <div class="admin-brand">
                    <h1>Admin Panel</h1>
                </div>
                
                <nav class="admin-menu">
                    <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">Dashboard</a>
                    <a href="upload.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'upload.php' ? 'active' : ''; ?>">Upload</a>
                    <a href="documents.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'documents.php' ? 'active' : ''; ?>">Documents</a>
                    <a href="categories.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'categories.php' ? 'active' : ''; ?>">Categories</a>
                    <a href="analytics.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'analytics.php' ? 'active' : ''; ?>">Analytics</a>
                    <a href="view-emails.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'view-emails.php' ? 'active' : ''; ?>">View Emails</a>
                </nav>
                
                <div class="admin-actions">
                    <a href="../index.php" class="btn btn-outline btn-sm" target="_blank">View Site</a>
                    <a href="logout.php" class="btn btn-secondary btn-sm">Logout</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="admin-main">
