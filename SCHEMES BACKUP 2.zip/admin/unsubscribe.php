<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$email = isset($_GET['email']) ? trim($_GET['email']) : '';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('Invalid email address.');
}

$emails_file = DATA_DIR . 'emails.csv';
$unsubscribed_file = DATA_DIR . 'unsubscribed.csv';
$emails = [];
$found = false;

// Read and filter emails
if (file_exists($emails_file)) {
    $handle = fopen($emails_file, 'r');
    while (($row = fgetcsv($handle)) !== false) {
        if (isset($row[0]) && strtolower($row[0]) === strtolower($email)) {
            $found = true;
            // Save to unsubscribed.csv
            $row[4] = date('Y-m-d H:i:s');
            file_put_contents($unsubscribed_file, implode(',', $row) . PHP_EOL, FILE_APPEND);
            continue; // Skip this row
        }
        $emails[] = $row;
    }
    fclose($handle);

    // Rewrite emails.csv
    $handle = fopen($emails_file, 'w');
    foreach ($emails as $row) {
        fputcsv($handle, $row);
    }
    fclose($handle);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Unsubscribe</title>
    <style>
        body { font-family: Arial; text-align: center; padding: 50px; background: #f8fafc; }
        .message { max-width: 600px; margin: auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .success { color: #047857; font-size: 20px; font-weight: 600; }
        .fail { color: #dc2626; font-size: 18px; }
    </style>
</head>
<body>
    <div class="message">
        <?php if ($found): ?>
            <div class="success">You have been unsubscribed from future emails.</div>
        <?php else: ?>
            <div class="fail">Your email address was not found in our list.</div>
        <?php endif; ?>
    </div>
</body>
</html>
