<?php
// Path to your categories.csv file
$csvFile = __DIR__ . '/../data/categories.csv'; // adjust path if needed

if (!file_exists($csvFile)) {
    exit("❌ File not found: $csvFile\n");
}

// Read CSV into array
$rows = [];
$headers = [];

if (($handle = fopen($csvFile, 'r')) !== false) {
    $headers = fgetcsv($handle);
    while (($row = fgetcsv($handle)) !== false) {
        $rows[] = array_combine($headers, $row);
    }
    fclose($handle);
}

// Ensure 'icon' column exists in header
if (!in_array('icon', $headers)) {
    $headers[] = 'icon';
    foreach ($rows as &$row) {
        $row['icon'] = '<i class="fas fa-folder"></i>'; // Default icon
    }
} else {
    // Add default icon where missing
    foreach ($rows as &$row) {
        if (!isset($row['icon']) || trim($row['icon']) === '') {
            $row['icon'] = '<i class="fas fa-folder"></i>';
        }
    }
}

// Write back to CSV
if (($handle = fopen($csvFile, 'w')) !== false) {
    fputcsv($handle, $headers);
    foreach ($rows as $row) {
        // Ensure row order matches header
        $ordered = [];
        foreach ($headers as $header) {
            $ordered[] = isset($row[$header]) ? $row[$header] : '';
        }
        fputcsv($handle, $ordered);
    }
    fclose($handle);
    echo "✅ categories.csv updated successfully with icon fields.\n";
} else {
    echo "❌ Failed to write to $csvFile\n";
}
