<?php
require_once '../includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Send Campaign – Schemes.co.ke</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800">
  <div class="max-w-4xl mx-auto mt-10 p-6 bg-white shadow rounded">
    <h1 class="text-2xl font-bold text-green-700 mb-4">📢 Send Email Campaign</h1>

    <form method="POST" action="send_campaign.php" onsubmit="return confirmSend()" id="campaignForm">
      <!-- Category Dropdown -->
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1">Campaign Category (for internal tracking)</label>
        <select name="category" id="category" class="w-full border border-gray-300 rounded px-3 py-2">
          <option value="General">General</option>
          <option value="Playgroup">Playgroup</option>
          <option value="PP1">PP1</option>
          <option value="PP2">PP2</option>
          <option value="Grade 1">Grade 1</option>
          <option value="Grade 2">Grade 2</option>
          <option value="Grade 3">Grade 3</option>
          <option value="Grade 4">Grade 4</option>
          <option value="Grade 5">Grade 5</option>
          <option value="Grade 6">Grade 6</option>
          <option value="Grade 7">Grade 7</option>
          <option value="Grade 8">Grade 8</option>
          <option value="Grade 9">Grade 9</option>
          <option value="Secondary">Secondary</option>
          <option value="Pre-primary">Pre-primary</option>
          <option value="Primary">Primary</option>
          <option value="Junior School">Junior School</option>
          <option value="College">College</option>
        </select>
      </div>

      <!-- Scheduling -->
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1">Schedule Campaign (optional)</label>
        <input type="datetime-local" name="schedule_time" class="w-full border border-gray-300 rounded px-3 py-2" />
        <p class="text-sm text-gray-500 mt-1">Leave blank to send immediately</p>
      </div>

      <!-- Email Count -->
      <div class="mb-4">
        <p class="text-sm text-gray-600">📧 Emails in <code class="bg-gray-100 px-1 py-0.5 rounded text-xs">emails.csv</code> will be used.</p>
        <p class="text-sm text-blue-600" id="email-count">Loading recipient count...</p>
      </div>

      <!-- Buttons -->
      <div class="flex items-center gap-4 mt-6">
        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded text-sm font-medium">
          🚀 Send Campaign
        </button>
        <button type="button" onclick="showPreview()" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm">👁️ Preview Email</button>
      </div>
    </form>

    <!-- Email Preview Section -->
    <div id="preview-section" class="mt-10 hidden">
      <h2 class="text-xl font-semibold text-gray-700 mb-4">📬 Email Preview</h2>
      <div class="border rounded p-4 bg-white shadow-inner prose prose-sm max-w-none" id="email-preview">
        <!-- Insert preview from JS -->
      </div>
    </div>
  </div>

  <script>
    // Load recipient count
    fetch('../data/emails.csv')
      .then(res => res.text())
      .then(text => {
        const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
        document.getElementById('email-count').innerText = `📨 Total recipients: ${lines.length}`;
      });

    function showPreview() {
      const category = document.getElementById('category').value;
      const previewHTML = `
        <div class="text-gray-800">
          <p>Dear Learner,</p>
          <p>A subscription to our portal gives you full access to resources across Preprimary, Primary, Junior School, Secondary and College Sections — enabling downloads, printing, and more.</p>
          <a href="https://schemes.co.ke/register" class="inline-block bg-green-600 text-white px-4 py-2 rounded mt-3">Register / Renew Access</a>

          <div class="mt-4">
            <h3 class="font-semibold text-green-700">Featured Sections:</h3>
            <ul class="grid grid-cols-2 gap-2 mt-2 text-sm">
              <li><a class="text-blue-600 hover:underline" href="https://schemes.co.ke/browse.php?category=Playgroup">🎯 Playgroup Exams</a></li>
              <li><a class="text-blue-600 hover:underline" href="https://schemes.co.ke/browse.php?category=PP1">📝 PP1 Exams</a></li>
              <li><a class="text-blue-600 hover:underline" href="https://schemes.co.ke/browse.php?category=Grade 1">📘 Grade 1 Exams</a></li>
              <li><a class="text-blue-600 hover:underline" href="https://schemes.co.ke/browse.php?category=Grade 4">📗 Grade 4 Exams</a></li>
              <li><a class="text-blue-600 hover:underline" href="https://schemes.co.ke/browse.php?category=Secondary">🏫 Secondary Full Set</a></li>
              <li><a class="text-blue-600 hover:underline" href="https://schemes.co.ke/browse.php?category=College">🎓 College & University</a></li>
            </ul>
          </div>

          <p class="mt-4 text-sm text-gray-600">
            To unsubscribe, click here:
            <a href="https://schemes.co.ke/unsubscribe.php?email=user@example.com" class="text-red-500 underline">https://schemes.co.ke/unsubscribe.php?email=user@example.com</a>
          </p>
        </div>
      `;
      document.getElementById('email-preview').innerHTML = previewHTML;
      document.getElementById('preview-section').classList.remove('hidden');
      window.scrollTo(0, document.body.scrollHeight);
    }

    function confirmSend() {
      const confirmMsg = "This will send the campaign to all emails listed. Proceed?";
      return confirm(confirmMsg);
    }
  </script>
</body>
</html>
