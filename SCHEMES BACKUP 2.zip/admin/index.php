<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Admin Dashboard';

// Get statistics
$categories = csv_to_array(DATA_DIR . 'categories.csv');
$documents = csv_to_array(DATA_DIR . 'documents.csv');
$total_downloads = array_sum(array_column($documents, 'hits'));
$recent_docs = array_slice($documents, -10);

include 'header.php';
?>

<div class="admin-content">
    <div class="dashboard-header">
        <h1>Dashboard</h1>
        <p>Welcome back! Here's what's happening with your library.</p>
    </div>
    
    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2v11z"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo count($categories); ?></h3>
                <p>Categories</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14,2 14,8 20,8"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo count($documents); ?></h3>
                <p>Documents</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7,10 12,15 17,10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_downloads); ?></h3>
                <p>Total Downloads</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3>KES <?php echo number_format(array_sum(array_column($documents, 'price'))); ?></h3>
                <p>Total Value</p>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="quick-actions">
        <h2>Quick Actions</h2>
        <div class="actions-grid">
            <a href="upload.php" class="action-card">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17,8 12,3 7,8"/>
                    <line x1="12" y1="3" x2="12" y2="15"/>
                </svg>
                <h3>Upload Document</h3>
                <p>Add new educational resources</p>
            </a>
            
            <a href="categories.php" class="action-card">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2v11z"/>
                </svg>
                <h3>Manage Categories</h3>
                <p>Organize your content structure</p>
            </a>
            
            <a href="documents.php" class="action-card">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14,2 14,8 20,8"/>
                </svg>
                <h3>View Documents</h3>
                <p>Manage existing resources</p>
            </a>
            
            <a href="analytics.php" class="action-card">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
                </svg>
                <h3>Analytics</h3>
                <p>View download statistics</p>
            </a>
        </div>
    </div>
    
    <!-- Recent Documents -->
    <div class="recent-section">
        <h2>Recent Documents</h2>
        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Downloads</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_reverse($recent_docs) as $doc): ?>
                    <?php $category = get_category_by_id($doc['category_id']); ?>
                    <tr>
                        <td>
                            <div class="doc-title">
                                <div class="file-icon">
                                    <?php if (pathinfo($doc['filename'], PATHINFO_EXTENSION) === 'pdf'): ?>
                                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                        <polyline points="14,2 14,8 20,8"/>
                                    </svg>
                                    <?php else: ?>
                                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                        <polyline points="14,2 14,8 20,8"/>
                                    </svg>
                                    <?php endif; ?>
                                </div>
                                <?php echo e($doc['title']); ?>
                            </div>
                        </td>
                        <td><?php echo $category ? e($category['title']) : 'N/A'; ?></td>
                        <td><?php echo money_fmt($doc['price']); ?></td>
                        <td><?php echo number_format($doc['hits']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($doc['date_uploaded'])); ?></td>
                        <td>
                            <div class="action-buttons">
                                <a href="edit-document.php?id=<?php echo e($doc['id']); ?>" class="btn btn-sm btn-outline">Edit</a>
                                <a href="../item.php?id=<?php echo e($doc['id']); ?>" class="btn btn-sm btn-primary" target="_blank">View</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
