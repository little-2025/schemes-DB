</main>

    <!-- Admin Footer -->
    <footer class="admin-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> Admin Panel</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="../assets/main.js"></script>
    <script src="../assets/admin.js"></script>
</body>
</html>
