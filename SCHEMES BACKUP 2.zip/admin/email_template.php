<?php
function generateEmailBody($recipientEmail, $randomDocuments) {
    $html = "<!DOCTYPE html><html><head><style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { padding: 20px; background: #f8f8f8; }
        h2 { color: #047857; }
        .doc-card { background: #fff; border-radius: 6px; padding: 10px 15px; margin: 10px 0; box-shadow: 0 0 5px #ddd; }
        .doc-link { color: #047857; text-decoration: none; font-weight: bold; }
    </style></head><body><div class='container'>";
    $html .= "<h2>Hello, here are new educational resources for you</h2>";

    foreach ($randomDocuments as $category => $docs) {
        $html .= "<h3>$category</h3>";
        foreach ($docs as $doc) {
            $html .= "<div class='doc-card'>
                        <p><a class='doc-link' href='" . SITE_URL . "/item.php?file=" . urlencode($doc['filename']) . "'>" . htmlspecialchars($doc['filename']) . "</a></p>
                      </div>";
        }
    }

    $html .= "<p style='margin-top:30px;'>Thank you for being part of our learning community!<br>Team @ Schemes.co.ke</p>";
    $html .= "</div></body></html>";

    return $html;
}
?>
