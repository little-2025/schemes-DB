<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

// Get document ID
$doc_id = intval($_GET['id'] ?? 0);
if (!$doc_id) {
    header('Location: documents.php');
    exit;
}

// Get document details
$document = get_document($doc_id);
if (!$document) {
    header('Location: documents.php');
    exit;
}

$page_title = 'Edit Document - ' . $document['title'];
$success = '';
$error = '';

// Get categories for dropdown
$categories = csv_to_array(DATA_DIR . 'categories.csv');

if ($_POST && verify_csrf($_POST['csrf_token'] ?? '')) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category_id = $_POST['category_id'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    
    // Validate inputs
    if (empty($title) || empty($description) || empty($category_id)) {
        $error = 'Please fill in all required fields';
    } else {
        $documents = csv_to_array(DATA_DIR . 'documents.csv');
        $updated = false;
        
        // Handle file replacement if uploaded
        $new_filename = $document['filename'];
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['file'];
            $allowed_types = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx'];
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_ext, $allowed_types)) {
                $error = 'Invalid file type. Allowed: ' . implode(', ', $allowed_types);
            } elseif ($file['size'] > 50 * 1024 * 1024) { // 50MB limit
                $error = 'File too large. Maximum size: 50MB';
            } else {
                // Delete old file
                $old_file_path = DOCS_DIR . $document['filename'];
                if (file_exists($old_file_path)) {
                    unlink($old_file_path);
                }
                
                // Upload new file
                $new_filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
                $upload_path = DOCS_DIR . $new_filename;
                
                if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
                    $error = 'Failed to upload new file';
                }
            }
        }
        
        if (empty($error)) {
            // Update document in array
            foreach ($documents as &$doc) {
                if ($doc['id'] == $doc_id) {
                    $doc['title'] = $title;
                    $doc['description'] = $description;
                    $doc['category_id'] = $category_id;
                    $doc['price'] = $price;
                    $doc['filename'] = $new_filename;
                    $updated = true;
                    break;
                }
            }
            
            if ($updated) {
                save_documents_csv($documents);
                
                // Clear cache
                $cache_file = CACHE_DIR . 'csv_' . md5(DATA_DIR . 'documents.csv') . '.json';
                if (file_exists($cache_file)) {
                    unlink($cache_file);
                }
                
                $success = 'Document updated successfully!';
                
                // Refresh document data
                $document = get_document($doc_id);
            } else {
                $error = 'Failed to update document';
            }
        }
    }
}

include 'header.php';
?>

<div class="admin-content">
    <div class="page-header">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1>Edit Document</h1>
                <p>Update document details and content</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <a href="../item.php?id=<?php echo $doc_id; ?>" class="btn btn-outline" target="_blank">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                    </svg>
                    View Document
                </a>
                <a href="documents.php" class="btn btn-secondary">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="15,18 9,12 15,6"/>
                    </svg>
                    Back to Documents
                </a>
            </div>
        </div>
    </div>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?php echo e($success); ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="alert alert-error">
        <?php echo e($error); ?>
    </div>
    <?php endif; ?>
    
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
        <!-- Edit Form -->
        <div class="upload-container">
            <form method="POST" enctype="multipart/form-data" class="upload-form">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="title">Document Title *</label>
                        <input type="text" id="title" name="title" required value="<?php echo e($document['title']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">Category *</label>
                        <select id="category_id" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                            <option value="<?php echo e($category['id']); ?>" <?php echo $document['category_id'] == $category['id'] ? 'selected' : ''; ?>>
                                <?php echo e($category['title']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" rows="4" required><?php echo e($document['description']); ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Price (KES)</label>
                        <input type="number" id="price" name="price" min="0" step="0.01" value="<?php echo e($document['price']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="file">Replace Document File (optional)</label>
                        <input type="file" id="file" name="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx">
                        <small>Leave empty to keep current file. Max: 50MB</small>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Document</button>
                    <a href="documents.php" class="btn btn-outline">Cancel</a>
                </div>
            </form>
        </div>
        
        <!-- Document Info -->
        <div>
            <!-- Current File Info -->
            <div style="background: #ffffff; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); margin-bottom: 1.5rem;">
                <h3 style="margin-bottom: 1rem;">Current File</h3>
                
                <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                    <div class="file-icon" style="width: 48px; height: 48px; background: #e7f9f4; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                        <?php if (pathinfo($document['filename'], PATHINFO_EXTENSION) === 'pdf'): ?>
                        <svg style="width: 24px; height: 24px; stroke: #047857;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <polyline points="14,2 14,8 20,8"/>
                            <line x1="16" y1="13" x2="8" y2="13"/>
                            <line x1="16" y1="17" x2="8" y2="17"/>
                            <polyline points="10,9 9,9 8,9"/>
                        </svg>
                        <?php else: ?>
                        <svg style="width: 24px; height: 24px; stroke: #047857;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <polyline points="14,2 14,8 20,8"/>
                            <line x1="12" y1="18" x2="12" y2="12"/>
                            <line x1="9" y1="15" x2="15" y2="15"/>
                        </svg>
                        <?php endif; ?>
                    </div>
                    <div>
                        <p><strong><?php echo e($document['filename']); ?></strong></p>
                        <p style="color: #6b7280; font-size: 0.875rem;">
                            <?php 
                            $file_path = DOCS_DIR . $document['filename'];
                            if (file_exists($file_path)) {
                                echo formatFileSize(filesize($file_path));
                            } else {
                                echo '<span style="color: #ef4444;">File missing</span>';
                            }
                            ?>
                        </p>
                    </div>
                </div>
                
                <?php if (file_exists(DOCS_DIR . $document['filename'])): ?>
                <a href="../download.php?id=<?php echo $doc_id; ?>&paid=1" class="btn btn-outline btn-sm" style="width: 100%;">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7,10 12,15 17,10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    Download Current File
                </a>
                <?php endif; ?>
            </div>
            
            <!-- Document Statistics -->
            <div style="background: #ffffff; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                <h4 style="margin-bottom: 1rem;">Statistics</h4>
                <div style="display: grid; gap: 1rem;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Downloads:</span>
                        <strong style="color: #047857;"><?php echo number_format($document['hits']); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Price:</span>
                        <strong><?php echo money_fmt($document['price']); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>Date Added:</span>
                        <strong><?php echo date('M j, Y', strtotime($document['date_uploaded'])); ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>File Type:</span>
                        <strong><?php echo strtoupper(pathinfo($document['filename'], PATHINFO_EXTENSION)); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
