<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Manage Documents';
$success = '';
$error = '';

// Handle document deletion
if (isset($_GET['delete']) && verify_csrf($_GET['token'] ?? '')) {
    $doc_id = intval($_GET['delete']);
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    
    $found = false;
    foreach ($documents as $index => $doc) {
        if ($doc['id'] == $doc_id) {
            // Delete the file
            $file_path = DOCS_DIR . $doc['filename'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
            
            // Remove from array
            unset($documents[$index]);
            $found = true;
            break;
        }
    }
    
    if ($found) {
        // Re-index array and save
        $documents = array_values($documents);
        save_documents_csv($documents);
        
        // Clear cache
        $cache_file = CACHE_DIR . 'csv_' . md5(DATA_DIR . 'documents.csv') . '.json';
        if (file_exists($cache_file)) {
            unlink($cache_file);
        }
        
        $success = 'Document deleted successfully!';
    } else {
        $error = 'Document not found!';
    }
}

// Get all documents with category info
$documents = csv_to_array(DATA_DIR . 'documents.csv');
$categories = csv_to_array(DATA_DIR . 'categories.csv');

// Create category lookup
$category_lookup = [];
foreach ($categories as $category) {
    $category_lookup[$category['id']] = $category['title'];
}

// Sort documents by date (newest first)
usort($documents, function($a, $b) {
    return strtotime($b['date_uploaded']) - strtotime($a['date_uploaded']);
});

include 'header.php';
?>

<div class="admin-content">
    <div class="page-header">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1>Manage Documents</h1>
                <p>View, edit, and delete educational resources</p>
            </div>
            <a href="upload.php" class="btn btn-primary">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17,8 12,3 7,8"/>
                    <line x1="12" y1="3" x2="12" y2="15"/>
                </svg>
                Upload New Document
            </a>
        </div>
    </div>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?php echo e($success); ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="alert alert-error">
        <?php echo e($error); ?>
    </div>
    <?php endif; ?>
    
    <!-- Documents Statistics -->
    <div class="stats-grid" style="margin-bottom: 2rem;">
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14,2 14,8 20,8"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo count($documents); ?></h3>
                <p>Total Documents</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7,10 12,15 17,10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format(array_sum(array_column($documents, 'hits'))); ?></h3>
                <p>Total Downloads</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3>KES <?php echo number_format(array_sum(array_column($documents, 'price'))); ?></h3>
                <p>Total Value</p>
            </div>
        </div>
    </div>
    
    <!-- Documents Table -->
    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Document</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Downloads</th>
                    <th>File Size</th>
                    <th>Date Added</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($documents)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 3rem; color: #6b7280;">
                        <svg style="width: 48px; height: 48px; margin-bottom: 1rem; stroke: #9ca3af;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <polyline points="14,2 14,8 20,8"/>
                        </svg>
                        <br>
                        No documents found. <a href="upload.php">Upload your first document</a>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($documents as $doc): ?>
                <tr>
                    <td>
                        <div class="doc-title">
                            <div class="file-icon">
                                <?php if (pathinfo($doc['filename'], PATHINFO_EXTENSION) === 'pdf'): ?>
                                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                    <polyline points="14,2 14,8 20,8"/>
                                    <line x1="16" y1="13" x2="8" y2="13"/>
                                    <line x1="16" y1="17" x2="8" y2="17"/>
                                    <polyline points="10,9 9,9 8,9"/>
                                </svg>
                                <?php else: ?>
                                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                    <polyline points="14,2 14,8 20,8"/>
                                    <line x1="12" y1="18" x2="12" y2="12"/>
                                    <line x1="9" y1="15" x2="15" y2="15"/>
                                </svg>
                                <?php endif; ?>
                            </div>
                            <div>
                                <strong><?php echo e($doc['title']); ?></strong>
                                <br>
                                <small style="color: #6b7280;"><?php echo e(substr($doc['description'], 0, 60)); ?>...</small>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($category_lookup[$doc['category_id']] ?? 'Unknown'); ?></td>
                    <td><?php echo money_fmt($doc['price']); ?></td>
                    <td>
                        <span style="font-weight: 600; color: #047857;">
                            <?php echo number_format($doc['hits']); ?>
                        </span>
                    </td>
                    <td>
                        <?php 
                        $file_path = DOCS_DIR . $doc['filename'];
                        if (file_exists($file_path)) {
                            $size = filesize($file_path);
                            echo formatFileSize($size);
                        } else {
                            echo '<span style="color: #ef4444;">Missing</span>';
                        }
                        ?>
                    </td>
                    <td><?php echo date('M j, Y', strtotime($doc['date_uploaded'])); ?></td>
                    <td>
                        <div class="action-buttons">
                            <a href="../item.php?id=<?php echo e($doc['id']); ?>" class="btn btn-sm btn-outline" target="_blank" title="View">
                                <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                            </a>
                            <a href="edit-document.php?id=<?php echo e($doc['id']); ?>" class="btn btn-sm btn-primary" title="Edit">
                                <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                </svg>
                            </a>
                            <a href="?delete=<?php echo e($doc['id']); ?>&token=<?php echo csrf_token(); ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('Are you sure you want to delete this document? This action cannot be undone.')" 
                               title="Delete">
                                <svg class="icon" style="width: 16px; height: 16px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3,6 5,6 21,6"/>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                    <line x1="10" y1="11" x2="10" y2="17"/>
                                    <line x1="14" y1="11" x2="14" y2="17"/>
                                </svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
.btn-danger {
    background: #ef4444;
    color: #ffffff;
}

.btn-danger:hover {
    background: #dc2626;
    color: #ffffff;
}

.doc-title {
    display: flex;
    align-items: center;
    gap: 12px;
}

.file-icon {
    width: 40px;
    height: 40px;
    background: #e7f9f4;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.file-icon svg {
    width: 20px;
    height: 20px;
    stroke: #047857;
}
</style>

<?php include 'footer.php'; ?>
