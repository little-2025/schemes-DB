<?php
require_once(__DIR__ . '/../includes/config.php');

$category = $_GET['category'] ?? '';
$count = 0;

if (($handle = fopen(DATA_DIR . 'emails.csv', 'r')) !== false) {
    $headers = fgetcsv($handle);
    while (($row = fgetcsv($handle)) !== false) {
        if (strtolower(trim($row[1])) == strtolower($category)) {
            $count++;
        }
    }
    fclose($handle);
}
echo $count;
