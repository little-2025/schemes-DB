<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Upload Document';
$success = '';
$error = '';

// Get hierarchical data
$categories = csv_to_array(DATA_DIR . 'categories.csv');
$levels = csv_to_array(DATA_DIR . 'education_levels.csv');
$grades = csv_to_array(DATA_DIR . 'grades.csv');
$terms = csv_to_array(DATA_DIR . 'terms.csv');

if ($_POST && verify_csrf($_POST['csrf_token'] ?? '')) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category_id = $_POST['category_id'] ?? '';
    $level_id = $_POST['level_id'] ?? '';
    $grade_id = $_POST['grade_id'] ?? '';
    $term_id = $_POST['term_id'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    
    // Validate inputs
    if (empty($title) || empty($description) || empty($category_id)) {
        $error = 'Please fill in all required fields';
    } elseif (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please select a file to upload';
    } else {
        // Validate file
        $file = $_FILES['file'];
        $allowed_types = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($file_ext, $allowed_types)) {
            $error = 'Invalid file type. Allowed: ' . implode(', ', $allowed_types);
        } elseif ($file['size'] > 50 * 1024 * 1024) { // 50MB limit
            $error = 'File too large. Maximum size: 50MB';
        } else {
            // Get hierarchy info for directory structure
            $category = get_category_by_id($category_id);
            $level = $level_id ? get_level_by_id($level_id) : null;
            $grade = $grade_id ? get_grade_by_id($grade_id) : null;
            $term = $term_id ? get_term_by_id($term_id) : null;
            
            // Create directory structure
            $upload_dir = create_file_directory(
                $category['slug'],
                $level ? $level['slug'] : null,
                $grade ? $grade['slug'] : null,
                $term ? $term['slug'] : null
            );
            
            // Generate unique filename
            $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
            $upload_path = $upload_dir . '/' . $filename;
            
            // Create relative path for database
            $relative_path = str_replace(DOCS_DIR, '', $upload_path);
            
            if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                // Add to documents CSV
                $documents = csv_to_array(DATA_DIR . 'documents.csv');
                $new_id = count($documents) + 1;
                
                $new_document = [
                    'id' => $new_id,
                    'title' => $title,
                    'category_id' => $category_id,
                    'level_id' => $level_id ?: '',
                    'grade_id' => $grade_id ?: '',
                    'term_id' => $term_id ?: '',
                    'price' => $price,
                    'filename' => $relative_path,
                    'description' => $description,
                    'hits' => 0,
                    'date_uploaded' => date('Y-m-d H:i:s')
                ];
                
                $documents[] = $new_document;
                save_documents_csv($documents);
                
                // Clear cache
                $cache_file = CACHE_DIR . 'csv_' . md5(DATA_DIR . 'documents.csv') . '.json';
                if (file_exists($cache_file)) {
                    unlink($cache_file);
                }
                
                $success = 'Document uploaded successfully to: ' . $relative_path;
                
                // Reset form
                $_POST = [];
            } else {
                $error = 'Failed to upload file';
            }
        }
    }
}

include 'header.php';
?>

<div class="admin-content">
    <div class="page-header">
        <h1>Upload Document</h1>
        <p>Add a new educational resource with proper hierarchical organization</p>
    </div>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?php echo e($success); ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="alert alert-error">
        <?php echo e($error); ?>
    </div>
    <?php endif; ?>
    
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
        <!-- Upload Form -->
        <div class="upload-container">
            <form method="POST" enctype="multipart/form-data" class="upload-form" id="uploadForm">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                
                <div class="form-group">
                    <label for="title">Document Title *</label>
                    <input type="text" id="title" name="title" required value="<?php echo e($_POST['title'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" rows="3" required><?php echo e($_POST['description'] ?? ''); ?></textarea>
                </div>
                
                <!-- Hierarchical Selection -->
                <div class="hierarchy-selection">
                    <h3>Hierarchical Organization</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="category_id">Category *</label>
                            <select id="category_id" name="category_id" required onchange="loadLevels()">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?php echo e($category['id']); ?>" <?php echo ($_POST['category_id'] ?? '') == $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo e($category['title']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="level_id">Education Level</label>
                            <select id="level_id" name="level_id" onchange="loadGrades()">
                                <option value="">Select Level</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="grade_id">Grade</label>
                            <select id="grade_id" name="grade_id" onchange="loadTerms()">
                                <option value="">Select Grade</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="term_id">Term</label>
                            <select id="term_id" name="term_id">
                                <option value="">Select Term</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Price (KES)</label>
                        <input type="number" id="price" name="price" min="0" step="0.01" value="<?php echo e($_POST['price'] ?? '0'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="file">Document File *</label>
                        <input type="file" id="file" name="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx" required>
                        <small>Allowed formats: PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX (Max: 50MB)</small>
                    </div>
                </div>
                
                <!-- Directory Preview -->
                <div class="directory-preview" id="directoryPreview" style="display: none;">
                    <h4>File will be saved to:</h4>
                    <div class="directory-path" id="directoryPath"></div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Upload Document</button>
                    <a href="documents.php" class="btn btn-outline">Cancel</a>
                </div>
            </form>
        </div>
        
        <!-- Hierarchy Guide -->
        <div>
            <div style="background: #ffffff; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); margin-bottom: 1.5rem;">
                <h3 style="margin-bottom: 1rem;">Hierarchy Guide</h3>
                <div class="hierarchy-guide">
                    <div class="guide-item">
                        <strong>Category</strong>
                        <p>Main subject area (e.g., Primary Notes, Secondary Notes)</p>
                    </div>
                    <div class="guide-item">
                        <strong>Education Level</strong>
                        <p>Learning stage (e.g., Lower Primary, Upper Primary)</p>
                    </div>
                    <div class="guide-item">
                        <strong>Grade</strong>
                        <p>Specific grade level (e.g., Grade 1, Form 1)</p>
                    </div>
                    <div class="guide-item">
                        <strong>Term</strong>
                        <p>Academic term (Term 1, Term 2, Term 3)</p>
                    </div>
                </div>
            </div>
            
            <!-- File Organization Preview -->
            <div style="background: #ffffff; padding: 2rem; border-radius: 12px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                <h4 style="margin-bottom: 1rem;">File Organization</h4>
                <div class="file-tree">
                    <div class="tree-item">📁 docs/</div>
                    <div class="tree-item level-1">📁 primary-notes/</div>
                    <div class="tree-item level-2">📁 lower-primary/</div>
                    <div class="tree-item level-3">📁 grade-1/</div>
                    <div class="tree-item level-4">📁 term-1/</div>
                    <div class="tree-item level-5">📄 document.pdf</div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hierarchy-selection {
    background: #f9fafb;
    padding: 1.5rem;
    border-radius: 8px;
    margin: 1.5rem 0;
}

.hierarchy-selection h3 {
    margin-bottom: 1rem;
    color: #374151;
}

.directory-preview {
    background: #e7f9f4;
    padding: 1rem;
    border-radius: 8px;
    margin: 1rem 0;
    border-left: 4px solid #047857;
}

.directory-path {
    font-family: monospace;
    background: #ffffff;
    padding: 0.5rem;
    border-radius: 4px;
    margin-top: 0.5rem;
    font-weight: 600;
    color: #047857;
}

.hierarchy-guide {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.guide-item {
    padding: 1rem;
    background: #f9fafb;
    border-radius: 6px;
    border-left: 3px solid #047857;
}

.guide-item strong {
    display: block;
    color: #047857;
    margin-bottom: 0.25rem;
}

.guide-item p {
    margin: 0;
    font-size: 0.875rem;
    color: #6b7280;
}

.file-tree {
    font-family: monospace;
    font-size: 0.875rem;
}

.tree-item {
    padding: 0.25rem 0;
    color: #374151;
}

.tree-item.level-1 { margin-left: 1rem; }
.tree-item.level-2 { margin-left: 2rem; }
.tree-item.level-3 { margin-left: 3rem; }
.tree-item.level-4 { margin-left: 4rem; }
.tree-item.level-5 { margin-left: 5rem; color: #047857; }
</style>

<script>
// Hierarchical data for dynamic loading
const hierarchyData = {
    levels: <?php echo json_encode($levels); ?>,
    grades: <?php echo json_encode($grades); ?>,
    terms: <?php echo json_encode($terms); ?>,
    categories: <?php echo json_encode($categories); ?>
};

function loadLevels() {
    const categoryId = document.getElementById('category_id').value;
    const levelSelect = document.getElementById('level_id');
    const gradeSelect = document.getElementById('grade_id');
    const termSelect = document.getElementById('term_id');
    
    // Clear dependent selects
    levelSelect.innerHTML = '<option value="">Select Level</option>';
    gradeSelect.innerHTML = '<option value="">Select Grade</option>';
    termSelect.innerHTML = '<option value="">Select Term</option>';
    
    if (categoryId) {
        const levels = hierarchyData.levels.filter(level => level.category_id == categoryId);
        levels.forEach(level => {
            const option = document.createElement('option');
            option.value = level.id;
            option.textContent = level.title;
            levelSelect.appendChild(option);
        });
    }
    
    updateDirectoryPreview();
}

function loadGrades() {
    const levelId = document.getElementById('level_id').value;
    const gradeSelect = document.getElementById('grade_id');
    const termSelect = document.getElementById('term_id');
    
    // Clear dependent selects
    gradeSelect.innerHTML = '<option value="">Select Grade</option>';
    termSelect.innerHTML = '<option value="">Select Term</option>';
    
    if (levelId) {
        const grades = hierarchyData.grades.filter(grade => grade.level_id == levelId);
        grades.forEach(grade => {
            const option = document.createElement('option');
            option.value = grade.id;
            option.textContent = grade.title;
            gradeSelect.appendChild(option);
        });
    }
    
    updateDirectoryPreview();
}

function loadTerms() {
    const gradeId = document.getElementById('grade_id').value;
    const termSelect = document.getElementById('term_id');
    
    // Clear dependent selects
    termSelect.innerHTML = '<option value="">Select Term</option>';
    
    if (gradeId) {
        const terms = hierarchyData.terms.filter(term => term.grade_id == gradeId);
        terms.forEach(term => {
            const option = document.createElement('option');
            option.value = term.id;
            option.textContent = term.title;
            termSelect.appendChild(option);
        });
    }
    
    updateDirectoryPreview();
}

function updateDirectoryPreview() {
    const categoryId = document.getElementById('category_id').value;
    const levelId = document.getElementById('level_id').value;
    const gradeId = document.getElementById('grade_id').value;
    const termId = document.getElementById('term_id').value;
    
    if (!categoryId) {
        document.getElementById('directoryPreview').style.display = 'none';
        return;
    }
    
    let path = 'docs/';
    
    // Add category
    const category = hierarchyData.categories.find(c => c.id == categoryId);
    if (category) {
        path += category.slug + '/';
    }
    
    // Add level
    if (levelId) {
        const level = hierarchyData.levels.find(l => l.id == levelId);
        if (level) {
            path += level.slug + '/';
        }
    }
    
    // Add grade
    if (gradeId) {
        const grade = hierarchyData.grades.find(g => g.id == gradeId);
        if (grade) {
            path += grade.slug + '/';
        }
    }
    
    // Add term
    if (termId) {
        const term = hierarchyData.terms.find(t => t.id == termId);
        if (term) {
            path += term.slug + '/';
        }
    }
    
    path += 'your-file.pdf';
    
    document.getElementById('directoryPath').textContent = path;
    document.getElementById('directoryPreview').style.display = 'block';
}

// Load levels on page load if category is selected
document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('category_id');
    if (categorySelect.value) {
        loadLevels();
    }
});
</script>
<?php include 'footer.php'; ?>
