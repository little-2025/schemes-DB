<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!is_admin()) {
    header('Location: login.php');
    exit;
}

$page_title = 'Analytics Dashboard';

// Get data
$documents = csv_to_array(DATA_DIR . 'documents.csv');
$categories = csv_to_array(DATA_DIR . 'categories.csv');

// Calculate statistics
$total_documents = count($documents);
$total_downloads = array_sum(array_column($documents, 'hits'));
$total_value = array_sum(array_column($documents, 'price'));
$avg_price = $total_documents > 0 ? $total_value / $total_documents : 0;

// Top performing documents
$top_documents = $documents;
usort($top_documents, function($a, $b) {
    return intval($b['hits']) - intval($a['hits']);
});
$top_documents = array_slice($top_documents, 0, 10);

// Category performance
$category_stats = [];
foreach ($categories as $category) {
    $cat_docs = array_filter($documents, function($doc) use ($category) {
        return $doc['category_id'] == $category['id'];
    });
    
    $category_stats[] = [
        'category' => $category,
        'document_count' => count($cat_docs),
        'total_downloads' => array_sum(array_column($cat_docs, 'hits')),
        'total_value' => array_sum(array_column($cat_docs, 'price'))
    ];
}

// Sort by downloads
usort($category_stats, function($a, $b) {
    return $b['total_downloads'] - $a['total_downloads'];
});

// Monthly upload trends (last 12 months)
$monthly_uploads = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $count = 0;
    
    foreach ($documents as $doc) {
        if (date('Y-m', strtotime($doc['date_uploaded'])) === $month) {
            $count++;
        }
    }
    
    $monthly_uploads[] = [
        'month' => date('M Y', strtotime("-$i months")),
        'count' => $count
    ];
}

// File type distribution
$file_types = [];
foreach ($documents as $doc) {
    $ext = strtoupper(pathinfo($doc['filename'], PATHINFO_EXTENSION));
    $file_types[$ext] = ($file_types[$ext] ?? 0) + 1;
}

include 'header.php';
?>

<div class="admin-content">
    <div class="page-header">
        <h1>Analytics Dashboard</h1>
        <p>Insights into your educational library performance</p>
    </div>
    
    <!-- Key Metrics -->
    <div class="stats-grid" style="margin-bottom: 3rem;">
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14,2 14,8 20,8"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_documents); ?></h3>
                <p>Total Documents</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7,10 12,15 17,10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3><?php echo number_format($total_downloads); ?></h3>
                <p>Total Downloads</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3>KES <?php echo number_format($total_value); ?></h3>
                <p>Total Library Value</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
                </svg>
            </div>
            <div class="stat-content">
                <h3>KES <?php echo number_format($avg_price); ?></h3>
                <p>Average Price</p>
            </div>
        </div>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 3rem;">
        <!-- Top Performing Documents -->
        <div class="analytics-card">
            <h3>Top Performing Documents</h3>
            <div class="analytics-list">
                <?php foreach (array_slice($top_documents, 0, 5) as $index => $doc): ?>
                <div class="analytics-item">
                    <div class="rank"><?php echo $index + 1; ?></div>
                    <div class="item-info">
                        <strong><?php echo e(substr($doc['title'], 0, 40)); ?>...</strong>
                        <div class="item-stats">
                            <span><?php echo number_format($doc['hits']); ?> downloads</span>
                            <span><?php echo money_fmt($doc['price']); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Category Performance -->
        <div class="analytics-card">
            <h3>Category Performance</h3>
            <div class="analytics-list">
                <?php foreach (array_slice($category_stats, 0, 5) as $stat): ?>
                <div class="analytics-item">
                   <div class="category-icon">
                     <?php echo isset($stat['category']['icon']) ? $stat['category']['icon'] : '<i                 class="fas fa-folder"></i>'; ?>
                      </div>

                    <div class="item-info">
                        <strong><?php echo e($stat['category']['title']); ?></strong>
                        <div class="item-stats">
                            <span><?php echo $stat['document_count']; ?> docs</span>
                            <span><?php echo number_format($stat['total_downloads']); ?> downloads</span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Charts Section -->
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; margin-bottom: 3rem;">
        <!-- Upload Trends -->
        <div class="analytics-card">
            <h3>Upload Trends (Last 12 Months)</h3>
            <div class="chart-container">
                <canvas id="uploadsChart" width="400" height="200"></canvas>
            </div>
        </div>
        
        <!-- File Types -->
        <div class="analytics-card">
            <h3>File Type Distribution</h3>
            <div class="file-types-list">
                <?php foreach ($file_types as $type => $count): ?>
                <div class="file-type-item">
                    <div class="file-type-info">
                        <span class="file-type-badge"><?php echo e($type); ?></span>
                        <span class="file-type-count"><?php echo $count; ?> files</span>
                    </div>
                    <div class="file-type-bar">
                        <div class="file-type-progress" style="width: <?php echo ($count / $total_documents) * 100; ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="analytics-card">
        <h3>Recent Activity</h3>
        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Document</th>
                        <th>Category</th>
                        <th>Downloads</th>
                        <th>Price</th>
                        <th>Date Added</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $recent_docs = $documents;
                    usort($recent_docs, function($a, $b) {
                        return strtotime($b['date_uploaded']) - strtotime($a['date_uploaded']);
                    });
                    $recent_docs = array_slice($recent_docs, 0, 10);
                    ?>
                    <?php foreach ($recent_docs as $doc): ?>
                    <?php $category = get_category_by_id($doc['category_id']); ?>
                    <tr>
                        <td>
                            <a href="../item.php?id=<?php echo e($doc['id']); ?>" target="_blank">
                                <?php echo e($doc['title']); ?>
                            </a>
                        </td>
                        <td><?php echo $category ? e($category['title']) : 'Unknown'; ?></td>
                        <td><?php echo number_format($doc['hits']); ?></td>
                        <td><?php echo money_fmt($doc['price']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($doc['date_uploaded'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.analytics-card {
    background: #ffffff;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.analytics-card h3 {
    margin-bottom: 1.5rem;
    color: #374151;
}

.analytics-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.analytics-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: #f9fafb;
    border-radius: 8px;
}

.rank {
    width: 32px;
    height: 32px;
    background: #047857;
    color: #ffffff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 0.9rem;
}

.category-icon {
    width: 32px;
    height: 32px;
    background: #e7f9f4;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.category-icon svg {
    width: 18px;
    height: 18px;
    stroke: #047857;
}

.item-info {
    flex: 1;
}

.item-stats {
    display: flex;
    gap: 1rem;
    margin-top: 0.25rem;
    font-size: 0.875rem;
    color: #6b7280;
}

.chart-container {
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f9fafb;
    border-radius: 8px;
    color: #6b7280;
}

.file-types-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.file-type-item {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.file-type-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.file-type-badge {
    background: #047857;
    color: #ffffff;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
}

.file-type-count {
    font-size: 0.875rem;
    color: #6b7280;
}

.file-type-bar {
    height: 6px;
    background: #e5e7eb;
    border-radius: 3px;
    overflow: hidden;
}

.file-type-progress {
    height: 100%;
    background: #047857;
    transition: width 0.3s ease;
}
</style>

<script>
// Simple chart placeholder - in production, you'd use Chart.js or similar
document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('uploadsChart');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        const data = <?php echo json_encode($monthly_uploads); ?>;
        
        // Simple bar chart
        const maxCount = Math.max(...data.map(d => d.count));
        const barWidth = canvas.width / data.length;
        const barMaxHeight = canvas.height - 40;
        
        ctx.fillStyle = '#047857';
        data.forEach((item, index) => {
            const barHeight = (item.count / maxCount) * barMaxHeight;
            const x = index * barWidth + 10;
            const y = canvas.height - barHeight - 20;
            
            ctx.fillRect(x, y, barWidth - 20, barHeight);
            
            // Labels
            ctx.fillStyle = '#6b7280';
            ctx.font = '10px Inter';
            ctx.fillText(item.month.split(' ')[0], x, canvas.height - 5);
            ctx.fillStyle = '#047857';
        });
    }
});
</script>

<?php include 'footer.php'; ?>
