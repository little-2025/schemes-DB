<?php
require_once 'includes/config.php';

$analytics_file = 'data/analytics.csv';
$temp_file = 'data/analytics_cleaned.csv';

if (!file_exists($analytics_file)) {
    die("Analytics file not found.");
}

$rows = [];
$headers = [];

if (($handle = fopen($analytics_file, 'r')) !== false) {
    $headers = fgetcsv($handle); // Read header row
    while (($data = fgetcsv($handle)) !== false) {
        $row = array_combine($headers, $data);

        // Keep row only if title and filename exist and file is present in /uploads/
        if (
            !empty($row['title']) &&
            !empty($row['filename']) &&
            file_exists(UPLOADS_DIR . $row['filename'])
        ) {
            $rows[] = $row;
        }
    }
    fclose($handle);
}

// Write cleaned data to temp file
if (($out = fopen($temp_file, 'w')) !== false) {
    fputcsv($out, $headers);
    foreach ($rows as $clean_row) {
        fputcsv($out, $clean_row);
    }
    fclose($out);
}

// Replace old file with cleaned version
rename($temp_file, $analytics_file);

echo "Analytics cleaned successfully. " . count($rows) . " valid entries retained.\n";
?>
