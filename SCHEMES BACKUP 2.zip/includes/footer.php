</main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Schemes.co.ke</h3>
                    <p>A comprehensive platform for Kenyan educational resources, including CBC, KIPSEA, KJSEA, KCSE (8-4-4), Junior Secondary School materials, and more.</p>
                    <div class="footer-social">
                        <p><strong>Contact Us:</strong></p>
                        <p>Email: info@schemes.co.ke</p>
                        <p>Phone: +254101787242</p>
                        <p>Mpesa Till: 5272685</p>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="<?php echo url(); ?>">Home</a></li>
                        <li><a href="<?php echo url('popular.php'); ?>">Popular Resources</a></li>
                        <li><a href="<?php echo url('about.php'); ?>">About Us</a></li>
                        <li><a href="<?php echo url('contact.php'); ?>">Contact</a></li>
                        <li><a href="<?php echo url('faq.php'); ?>">FAQ</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Categories</h4>
                    <ul>
                        <li><a href="<?php echo url('browse.php?category=primary-notes'); ?>">Primary Notes</a></li>
                        <li><a href="<?php echo url('browse.php?category=secondary-notes'); ?>">Secondary Notes</a></li>
                        <li><a href="<?php echo url('browse.php?category=kcse-revision'); ?>">KCSE Revision</a></li>
                        <li><a href="<?php echo url('browse.php?category=cbc-curriculum'); ?>">CBC Curriculum</a></li>
                        <li><a href="<?php echo url('browse.php?category=lesson-plans'); ?>">Lesson Plans</a></li>
                        <li><a href="<?php echo url('browse.php?category=exams'); ?>">Exams</a></li>
                        <li><a href="<?php echo url('browse.php?category=tests-cbc'); ?>">TESTS-CBC</a></li>
                         <li><a href="<?php echo url('browse.php?category=records-of-work'); ?>">Records of Work</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Legal & Support</h4>
                    <ul>
                        <li><a href="<?php echo url('privacy-policy.php'); ?>">Privacy Policy</a></li>
                        <li><a href="<?php echo url('terms-conditions.php'); ?>">Terms & Conditions</a></li>
                        <li><a href="<?php echo url('refund-policy.php'); ?>">Refund Policy</a></li>
                        <li><a href="<?php echo url('disclaimer.php'); ?>">Disclaimer</a></li>
                        <li><a href="<?php echo url('support.php'); ?>">Support Center</a></li>
                        <li><a href="<?php echo url('admin/index.php'); ?>">Admin</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Schemes Hub. All rights reserved.</p>
                <div class="footer-links">
                    <a href="<?php echo url('privacy-policy.php'); ?>">Privacy</a>
                    <a href="<?php echo url('terms-conditions.php'); ?>">Terms</a>
                    <a href="<?php echo url('sitemap.php'); ?>">Sitemap</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Payment Modal -->
    <div id="paymentModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Complete Payment</h2>
            <div class="payment-info">
                <p><strong>Mpesa Till Number:</strong> <?php echo MPESA_TILL; ?></p>
                <p><strong>Amount:</strong> <span id="paymentAmount"></span></p>
                <p>Send the payment to the till number above, then click "Mark as Paid" to download your file.</p>
            </div>
            <div class="modal-actions">
                <button id="markPaidBtn" class="btn btn-primary">Mark as Paid</button>
                <button class="btn btn-secondary" onclick="closePaymentModal()">Cancel</button>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="<?php echo ASSETS_DIR; ?>main.js"></script>
</body>
</html>
