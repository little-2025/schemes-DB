<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? e($page_title) . ' - ' : ''; ?><?php echo SITE_NAME; ?></title>
    <meta name="description" content="<?php echo isset($page_description) ? e($page_description) : 'Educational resources for Kenyan curriculum - CBC, KCSE, JSS materials'; ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="icon" type="image/png" href="/assets/favicon.png">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
<meta name="theme-color" content="#047857">
<!-- In header.php -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <!-- Preconnect to Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo ASSETS_DIR; ?>style.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?php echo ASSETS_DIR; ?>favicon.svg">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-top">
            <div class="container">
                <div class="header-contact">
                    <span class="contact-item">
                        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <polyline points="22,6 12,13 2,6"/>
                        </svg>
                        info@schemes.co.ke
                    </span>
                    <span class="contact-item">
                        <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                        +254 710 178 7242
                    </span>
                    <span class="contact-item mpesa-till">
                        Mpesa Till: 5272685
                    </span>
                </div>
            </div>
        </div>
        
        <nav class="navbar">
            <div class="container">
                <div class="nav-content">
                    <!-- Back Button (shown on non-home pages) -->
                    <?php if (basename($_SERVER['PHP_SELF']) !== 'index.php'): ?>
                    <button class="back-btn" onclick="history.back()" aria-label="Go back">
                        <span class="back-arrow">←</span> Back
                    </button>
                    <?php endif; ?>

                    <!-- Site Branding -->
                    <div class="site-branding">
                        <a href="<?php echo url(); ?>" class="site-logo">
                            <h1><?php echo SITE_NAME; ?></h1>
                        </a>
                    </div>
                    
                    <!-- Mobile Menu Toggle -->
                    <button class="mobile-toggle" id="mobileToggle" aria-label="Toggle menu">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                    
                    <!-- Navigation Menu -->
                    <ul class="nav-menu" id="navMenu">
                        <li><a href="<?php echo url(); ?>" class="<?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">Home</a></li>
                        <li><a href="<?php echo url('browse.php?category=lesson-plans'); ?>">Lesson Plans</a></li>
                        <li><a href="<?php echo url('browse.php?category=textbooks'); ?>">Textbooks</a></li>
                        <li><a href="<?php echo url('browse.php?category=records-of-work'); ?>">Records of Work</a></li>
                        <li><a href="<?php echo url('browse.php?category=tests-cbc'); ?>">Tests-CBC</a></li>
                        <li><a href="<?php echo url('browse.php?category=primary-notes'); ?>">Primary Notes</a></li>
                        <li><a href="<?php echo url('browse.php?category=jss-notes-topical'); ?>">JSS Notes</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="main-content">
