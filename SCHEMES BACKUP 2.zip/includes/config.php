<?php
/**
 *schemes - Configuration File
 * Contains site-wide constants and settings
 */

// Site Configuration
define('SITE_NAME', 'Schemes.co.ke');
define('SITE_URL', 'https://www.schemes.co.ke');
define('SITE_EMAIL', 'info@schemes.co.ke');
define('SITE_PHONE', '+254 717 787 242');
define('MPESA_TILL', '5272685');

// Directory Paths
define('DATA_DIR', __DIR__ . '/../data/');
define('DOCS_DIR', __DIR__ . '/../docs/');
define('ASSETS_DIR', '/assets/');
define('CACHE_DIR', __DIR__ . '/../cache/');

// Cache Settings
define('CACHE_TTL', 600); // 10 minutes

//paystack Settings
define('PAYSTACK_PUBLIC_KEY', 'pk_live_c2395ffcb9463d8d1f4bd16b973d349fd1f2dcb7');
define('PAYSTACK_SECRET_KEY', 'sk_live_ada5cd802690732ae7ab538f0e8cf44a4a37637d');

// Admin Settings
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', password_hash('Ndombi1996', PASSWORD_DEFAULT));

// Create necessary directories if they don't exist
$dirs = [DATA_DIR, DOCS_DIR, CACHE_DIR];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Start session
session_start();

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
