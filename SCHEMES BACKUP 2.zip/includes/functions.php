<?php
/**
 * Core utility functions for Elimu Library Clone
 */

/**
 * Convert CSV file to associative array
 */
function csv_to_array($file) {
    $cache_key = 'csv_' . md5($file);
    $cache_file = CACHE_DIR . $cache_key . '.json';
    
    // Check cache
    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < CACHE_TTL) {
        return json_decode(file_get_contents($cache_file), true);
    }
    
    if (!file_exists($file)) {
        return [];
    }
    
    $array = [];
    if (($handle = fopen($file, "r")) !== FALSE) {
        $header = fgetcsv($handle);
        while (($row = fgetcsv($handle)) !== FALSE) {
            if (count($row) === count($header)) {
                $array[] = array_combine($header, $row);
            }
        }
        fclose($handle);
    }
    
    // Cache result
    file_put_contents($cache_file, json_encode($array));
    return $array;
}

/**
 * Get category by slug
 */
function get_category($slug) {
    $categories = csv_to_array(DATA_DIR . 'categories.csv');
    foreach ($categories as $category) {
        if ($category['slug'] === $slug) {
            return $category;
        }
    }
    return null;
}

/**
 * Get category by ID
 */
function get_category_by_id($id) {
    $categories = csv_to_array(DATA_DIR . 'categories.csv');
    foreach ($categories as $category) {
        if ($category['id'] == $id) {
            return $category;
        }
    }
    return null;
}

/**
 * Get child categories
 */
function get_children($parent_id) {
    $categories = csv_to_array(DATA_DIR . 'categories.csv');
    $children = [];
    foreach ($categories as $category) {
        if (isset($category['parent_id']) && $category['parent_id'] == $parent_id) {
            $children[] = $category;
        }
    }

    usort($children, function($a, $b) {
        $ordA = isset($a['ordinal']) ? intval($a['ordinal']) : 0;
        $ordB = isset($b['ordinal']) ? intval($b['ordinal']) : 0;
        return $ordA - $ordB;
    });

    return $children;
}

/**
 * Get education levels for a category
 */
function get_education_levels($category_id) {
    $levels = csv_to_array(DATA_DIR . 'education_levels.csv');
    $filtered = [];
    foreach ($levels as $level) {
        if (isset($level['category_id']) && $level['category_id'] == $category_id) {
            $filtered[] = $level;
        }
    }

    usort($filtered, function($a, $b) {
        $ordA = isset($a['ordinal']) ? intval($a['ordinal']) : 0;
        $ordB = isset($b['ordinal']) ? intval($b['ordinal']) : 0;
        return $ordA - $ordB;
    });

    return $filtered;
}


/**
 * Get grades for an education level


/**
 * Get terms for a grade (if applicable)
 */
function get_grades($level_id) {
    $grades = csv_to_array(DATA_DIR . 'grades.csv');
    $filtered = [];
    foreach ($grades as $grade) {
        if (isset($grade['level_id']) && $grade['level_id'] == $level_id) {
            $filtered[] = $grade;
        }
    }

    usort($filtered, function($a, $b) {
        $ordA = isset($a['ordinal']) ? intval($a['ordinal']) : 0;
        $ordB = isset($b['ordinal']) ? intval($b['ordinal']) : 0;
        return $ordA - $ordB;
    });

    return $filtered;
}

function get_terms($grade_id) {
    $terms = csv_to_array(DATA_DIR . 'terms.csv');
    $filtered = [];
    foreach ($terms as $term) {
        if (isset($term['grade_id']) && $term['grade_id'] == $grade_id) {
            $filtered[] = $term;
        }
    }

    usort($filtered, function($a, $b) {
        $ordA = isset($a['ordinal']) ? intval($a['ordinal']) : 0;
        $ordB = isset($b['ordinal']) ? intval($b['ordinal']) : 0;
        return $ordA - $ordB;
    });

    return $filtered;
}

/**
 * Get documents by category
 */
function get_documents($category_id, $limit = null) {
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    $filtered = [];
    foreach ($documents as $document) {
        if ($document['category_id'] == $category_id) {
            $filtered[] = $document;
        }
    }
    
    // Sort by date uploaded (newest first)
    usort($filtered, function($a, $b) {
        return strtotime($b['date_uploaded']) - strtotime($a['date_uploaded']);
    });
    
    if ($limit) {
        return array_slice($filtered, 0, $limit);
    }
    return $filtered;
}

/**
 * Get documents by hierarchy
 */
function get_documents_by_hierarchy($category_id, $level_id = null, $grade_id = null, $term_id = null, $limit = null) {
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    $filtered = [];
    
    foreach ($documents as $document) {
        $match = true;
        
        if ($category_id && $document['category_id'] != $category_id) $match = false;
        if ($level_id && $document['level_id'] != $level_id) $match = false;
        if ($grade_id && $document['grade_id'] != $grade_id) $match = false;
        if ($term_id && $document['term_id'] != $term_id) $match = false;
        
        if ($match) {
            $filtered[] = $document;
        }
    }
    
    // Sort by date uploaded (newest first)
    usort($filtered, function($a, $b) {
        return strtotime($b['date_uploaded']) - strtotime($a['date_uploaded']);
    });
    
    if ($limit) {
        return array_slice($filtered, 0, $limit);
    }
    return $filtered;
}

/**
 * Get popular documents with real analytics
 */
function get_popular_documents($limit = 8, $days = 7) {
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    $analytics = get_analytics_data($days);

    $popular_docs = [];
    foreach ($documents as $doc) {
        $doc_id = $doc['id'];
        $weekly_downloads = isset($analytics[$doc_id]) ? $analytics[$doc_id]['weekly_downloads'] : 0;
        $growth_rate = isset($analytics[$doc_id]) ? $analytics[$doc_id]['growth_rate'] : 0;

        // Skip files with no downloads
        if ($weekly_downloads <= 0 && intval($doc['hits']) <= 0) {
            continue;
        }

        // Calculate popularity score
        $popularity_score = ($weekly_downloads * 0.7) + ($growth_rate * 0.3) + (intval($doc['hits']) * 0.1);

        $doc['weekly_downloads'] = $weekly_downloads;
        $doc['growth_rate'] = $growth_rate;
        $doc['popularity_score'] = $popularity_score;

        $popular_docs[] = $doc;
    }

    // Sort by popularity score
    usort($popular_docs, function($a, $b) {
        return $b['popularity_score'] <=> $a['popularity_score'];
    });

    return array_slice($popular_docs, 0, $limit);
}


/**
 * Get analytics data for documents
 */
function get_analytics_data($days = 7) {
    $analytics_file = DATA_DIR . 'analytics.csv';
    $analytics = [];


    $data = csv_to_array($analytics_file);  // ✅ Define $data correctly
    $cutoff_date = date('Y-m-d', strtotime("-$days days"));

    foreach ($data as $record) {
        if (isset($record['date']) && $record['date'] >= $cutoff_date) {
            $doc_id = isset($record['document_id']) ? $record['document_id'] : null;
            if (!$doc_id) continue;

            if (!isset($analytics[$doc_id])) {
                $analytics[$doc_id] = [
                    'weekly_downloads' => 0,
                    'daily_downloads' => [],
                    'growth_rate' => 0
                ];
            }

            $analytics[$doc_id]['weekly_downloads'] += intval($record['downloads']);
            $analytics[$doc_id]['daily_downloads'][$record['date']] = intval($record['downloads']);
        }
    }

    // Calculate growth rates
    foreach ($analytics as $doc_id => &$data) {
        $daily_downloads = array_values($data['daily_downloads']);
        if (count($daily_downloads) >= 2) {
            $recent_avg = array_sum(array_slice($daily_downloads, -3)) / 3;
            $older_avg = array_sum(array_slice($daily_downloads, 0, 3)) / 3;
            $data['growth_rate'] = $older_avg > 0 ? (($recent_avg - $older_avg) / $older_avg) * 100 : 0;
        }
    }

    return $analytics;
}

/**
 * Create sample analytics data
 */
function create_sample_analytics() {
    $analytics_file = DATA_DIR . 'analytics.csv';
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    
    $analytics_data = [];
    $analytics_data[] = ['date', 'document_id', 'downloads', 'views'];
    
    // Generate 30 days of sample data
    for ($i = 30; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        
        foreach ($documents as $doc) {
            // Simulate realistic download patterns
            $base_downloads = rand(0, 15);
            $weekend_factor = (date('N', strtotime($date)) >= 6) ? 0.6 : 1.0;
            $downloads = max(0, round($base_downloads * $weekend_factor));
            $views = $downloads * rand(3, 8);
            
            if ($downloads > 0 || rand(1, 3) == 1) {
                $analytics_data[] = [$date, $doc['id'], $downloads, $views];
            }
        }
    }
    
    // Write to CSV
    $handle = fopen($analytics_file, 'w');
    foreach ($analytics_data as $row) {
        fputcsv($handle, $row);
    }
    fclose($handle);
}

/**
 * Get document by ID
 */
function get_document($id) {
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    foreach ($documents as $document) {
        if ($document['id'] == $id) {
            return $document;
        }
    }
    return null;
}

/**
 * Get level by ID
 */
function get_level_by_id($id) {
    $levels = csv_to_array(DATA_DIR . 'education_levels.csv');
    foreach ($levels as $level) {
        if ($level['id'] == $id) {
            return $level;
        }
    }
    return null;
}

/**
 * Get grade by ID
 */
function get_grade_by_id($id) {
    $grades = csv_to_array(DATA_DIR . 'grades.csv');
    foreach ($grades as $grade) {
        if ($grade['id'] == $id) {
            return $grade;
        }
    }
    return null;
}

/**
 * Get term by ID
 */
function get_term_by_id($id) {
    $terms = csv_to_array(DATA_DIR . 'terms.csv');
    foreach ($terms as $term) {
        if ($term['id'] == $id) {
            return $term;
        }
    }
    return null;
}

/**
 * Format money
 */
function money_fmt($amount) {
    return 'KES ' . number_format($amount);
}

/**
 * Create URL slug
 */
function slugify($string) {
    return strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $string), '-'));
}

/**
 * Generate URL
 */
function url($path = '') {
    return SITE_URL . '/' . ltrim($path, '/');
}

/**
 * Sanitize output
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Generate breadcrumb
 */
function get_breadcrumb($category_id) {
    $breadcrumb = [];
    $current_id = $category_id;
    
    while ($current_id && $current_id != '0') {
        $category = get_category_by_id($current_id);
        if ($category) {
            array_unshift($breadcrumb, $category);
            $current_id = $category['parent_id'];
        } else {
            break;
        }
    }
    
    return $breadcrumb;
}

/**
 * Generate hierarchical breadcrumb
 */
function get_hierarchical_breadcrumb($category_id, $level_id = null, $grade_id = null, $term_id = null) {
    $crumbs = [];

    $category = get_category_by_id($category_id);
    if (!$category) return [];

    $level = $grade = $term = null;

    if ($level_id) {
        $level = get_level_by_id($level_id);
    }

    if ($grade_id) {
        $grade = get_grade_by_id($grade_id);
    }

    if ($term_id) {
        $term = get_term_by_id($term_id);
    }

    // Add category
    $crumbs[] = [
        'title' => $category['title'],
        'url'   => build_browse_url($category)
    ];

    // Add level if exists
    if ($level) {
        $crumbs[] = [
            'title' => $level['title'],
            'url'   => build_browse_url($category, $level)
        ];
    }

    // Add grade if exists
    if ($grade) {
        $crumbs[] = [
            'title' => $grade['title'],
            'url'   => build_browse_url($category, $level, $grade)
        ];
    }

    // Add term if exists
    if ($term) {
        $crumbs[] = [
            'title' => $term['title'],
            'url'   => build_browse_url($category, $level, $grade, $term)
        ];
    }

    return $crumbs;
}


/**
 * Search documents
 */
function search_documents($query, $limit = 20) {
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    $results = [];
    $query = strtolower($query);
    
    foreach ($documents as $document) {
        if (strpos(strtolower($document['title']), $query) !== false ||
            strpos(strtolower($document['description']), $query) !== false) {
            $results[] = $document;
        }
    }
    
    return array_slice($results, 0, $limit);
}

/**
 * Increment document hits
 */
function increment_hits($document_id) {
    $documents = csv_to_array(DATA_DIR . 'documents.csv');
    $updated = false;
    
    foreach ($documents as &$document) {
        if ($document['id'] == $document_id) {
            $document['hits'] = intval($document['hits']) + 1;
            $updated = true;
            break;
        }
    }
    
    if ($updated) {
        save_documents_csv($documents);
        // Clear cache
        $cache_file = CACHE_DIR . 'csv_' . md5(DATA_DIR . 'documents.csv') . '.json';
        if (file_exists($cache_file)) {
            unlink($cache_file);
        }
        
        // Log analytics
        log_download_analytics($document_id);
    }
}

/**
 * Log download analytics
 */
function log_download_analytics($document_id) {
    $analytics_file = DATA_DIR . 'analytics.csv';
    $today = date('Y-m-d');

    // Read existing data
    $analytics = [];
    if (file_exists($analytics_file)) {
        $analytics = csv_to_array($analytics_file);
    }

    $found = false;
    foreach ($analytics as &$record) {
        if (
            isset($record['date'], $record['document_id']) &&
            $record['date'] === $today &&
            $record['document_id'] == $document_id
        ) {
            $record['downloads'] = intval($record['downloads']) + 1;
            $record['views'] = intval($record['views']) + 1;
            $found = true;
            break;
        }
    }

    // Add new record if not found
    if (!$found) {
        $analytics[] = [
            'date' => $today,
            'document_id' => $document_id,
            'downloads' => 1,
            'views' => 1
        ];
    }

    // Save back to CSV
    $handle = fopen($analytics_file, 'w');
    if (!empty($analytics)) {
        fputcsv($handle, ['date', 'document_id', 'downloads', 'views']); // Always write header
        foreach ($analytics as $record) {
            fputcsv($handle, $record);
        }
    }
    fclose($handle);
}


/**
 * Save documents to CSV
 */
function save_documents_csv($documents) {
    $file = DATA_DIR . 'documents.csv';
    $handle = fopen($file, 'w');
    
    if (!empty($documents)) {
        // Write header
        fputcsv($handle, array_keys($documents[0]));
        
        // Write data
        foreach ($documents as $document) {
            fputcsv($handle, $document);
        }
    }
    
    fclose($handle);
}

/**
 * Create directory structure for file upload
 */
function create_file_directory($category_slug, $level_slug = null, $grade_slug = null, $term_slug = null) {
    $path = DOCS_DIR . $category_slug;
    
    if ($level_slug) {
        $path .= '/' . $level_slug;
    }
    
    if ($grade_slug) {
        $path .= '/' . $grade_slug;
    }
    
    if ($term_slug) {
        $path .= '/' . $term_slug;
    }
    
    if (!is_dir($path)) {
        mkdir($path, 0755, true);
    }
    
    return $path;
}

/**
 * Get file icon based on extension
 */
function get_file_icon($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    switch ($ext) {
        case 'pdf':
            return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14,2 14,8 20,8"/>
                        <line x1="16" y1="13" x2="8" y2="13"/>
                        <line x1="16" y1="17" x2="8" y2="17"/>
                        <polyline points="10,9 9,9 8,9"/>
                    </svg>';
        case 'doc':
        case 'docx':
            return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14,2 14,8 20,8"/>
                        <line x1="12" y1="18" x2="12" y2="12"/>
                        <line x1="9" y1="15" x2="15" y2="15"/>
                    </svg>';
        default:
            return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14,2 14,8 20,8"/>
                    </svg>';
    }
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    if ($bytes === 0) return '0 Bytes';
    
    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    
    return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}

/**
 * Check if user is admin
 */
function is_admin() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/**
 * Generate CSRF token
 */
function csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
function build_browse_url($category, $level = null, $grade = null, $term = null) {
    $params = [
        'category' => $category['slug']
    ];

    if ($level) {
        $params['level'] = $level['slug'];
        $params['level_id'] = $level['id'];
    }

    if ($grade) {
        $params['grade'] = $grade['slug'];
        $params['grade_id'] = $grade['id'];
    }

    if ($term) {
        $params['term'] = $term['slug'];
        $params['term_id'] = $term['id'];
    }

    return 'browse.php?' . http_build_query($params);
}

?>
