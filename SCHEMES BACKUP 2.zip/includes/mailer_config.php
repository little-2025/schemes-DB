<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/PHPMailer/src/Exception.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';

function getMailer() {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'mail.schemes.co.ke';     // Change this to your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = 'info@schemes.co.ke'; // Your domain email
        $mail->Password = 'Ndombi1996?';       // Email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Or PHPMailer::ENCRYPTION_STARTTLS
        $mail->Port = 465;                      // Use 465 for SSL or 587 for TLS

        // Sender
        $mail->setFrom('info@schemes.co.ke', 'Schemes.co.ke');
        return $mail;
    } catch (Exception $e) {
        return null;
    }
}
