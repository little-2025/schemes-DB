/**
 * SCHEMES.CO.KE - Main JavaScript
 */

// DOM Ready
document.addEventListener("DOMContentLoaded", () => {
  initializeNavigation()
  initializeModals()
  initializeSearch()
})

/**
 * Navigation functionality
 */
function initializeNavigation() {
  const mobileToggle = document.getElementById("mobileToggle")
  const navMenu = document.getElementById("navMenu")

  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")

      // Animate hamburger
      const spans = mobileToggle.querySelectorAll("span")
      spans.forEach((span, index) => {
        if (navMenu.classList.contains("active")) {
          if (index === 0) span.style.transform = "rotate(45deg) translate(5px, 5px)"
          if (index === 1) span.style.opacity = "0"
          if (index === 2) span.style.transform = "rotate(-45deg) translate(7px, -6px)"
        } else {
          span.style.transform = ""
          span.style.opacity = ""
        }
      })
    })

    // Close menu when clicking outside
    document.addEventListener("click", (e) => {
      if (!mobileToggle.contains(e.target) && !navMenu.contains(e.target)) {
        navMenu.classList.remove("active")
        const spans = mobileToggle.querySelectorAll("span")
        spans.forEach((span) => {
          span.style.transform = ""
          span.style.opacity = ""
        })
      }
    })
  }
}

/**
 * Modal functionality
 */
function initializeModals() {
  const modal = document.getElementById("paymentModal")
  const closeBtn = modal?.querySelector(".close")

  if (closeBtn) {
    closeBtn.addEventListener("click", closePaymentModal)
  }

  // Close modal when clicking outside
  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        closePaymentModal()
      }
    })
  }

  // Close modal with Escape key
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal?.style.display === "block") {
      closePaymentModal()
    }
  })
}

/**
 * Search functionality
 */
function initializeSearch() {
  const searchForms = document.querySelectorAll(".search-form")

  searchForms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      const input = form.querySelector('input[name="q"]')
      if (input && input.value.trim() === "") {
        e.preventDefault()
        input.focus()
        showAlert("Please enter a search term", "error")
      }
    })
  })
}

/**
 * Payment modal functions
 */
function openPaymentModal(docId, title, price) {
  const modal = document.getElementById("paymentModal")
  const amountSpan = document.getElementById("paymentAmount")
  const markPaidBtn = document.getElementById("markPaidBtn")

  if (modal && amountSpan && markPaidBtn) {
    amountSpan.textContent = "KES " + price.toLocaleString()

    markPaidBtn.onclick = () => {
      markAsPaid(docId)
    }

    modal.style.display = "block"
    document.body.style.overflow = "hidden"
  }
}

function closePaymentModal() {
  const modal = document.getElementById("paymentModal")
  if (modal) {
    modal.style.display = "none"
    document.body.style.overflow = ""
  }
}

function markAsPaid(docId) {
  // In a real implementation, you would verify payment here
  // For demo purposes, we'll just redirect to download
  window.location.href = "download.php?id=" + docId + "&paid=1"
}

/**
 * Alert system
 */
function showAlert(message, type = "info") {
  // Remove existing alerts
  const existingAlerts = document.querySelectorAll(".alert-dynamic")
  existingAlerts.forEach((alert) => alert.remove())

  // Create new alert
  const alert = document.createElement("div")
  alert.className = `alert alert-${type} alert-dynamic`
  alert.textContent = message
  alert.style.position = "fixed"
  alert.style.top = "20px"
  alert.style.right = "20px"
  alert.style.zIndex = "9999"
  alert.style.maxWidth = "400px"
  alert.style.animation = "slideInRight 0.3s ease"

  document.body.appendChild(alert)

  // Auto remove after 5 seconds
  setTimeout(() => {
    alert.style.animation = "slideOutRight 0.3s ease"
    setTimeout(() => alert.remove(), 300)
  }, 5000)

  // Click to dismiss
  alert.addEventListener("click", () => {
    alert.style.animation = "slideOutRight 0.3s ease"
    setTimeout(() => alert.remove(), 300)
  })
}

/**
 * File upload preview
 */
function previewFile(input) {
  const file = input.files[0]
  const preview = document.getElementById("filePreview")

  if (file && preview) {
    const fileName = file.name
    const fileSize = (file.size / 1024 / 1024).toFixed(2) + " MB"
    const fileType = file.type

    preview.innerHTML = `
            <div class="file-preview">
                <div class="file-icon">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14,2 14,8 20,8"/>
                    </svg>
                </div>
                <div class="file-info">
                    <p><strong>${fileName}</strong></p>
                    <p>Size: ${fileSize}</p>
                    <p>Type: ${fileType}</p>
                </div>
            </div>
        `
    preview.style.display = "block"
  }
}

/**
 * Form validation
 */
function validateForm(form) {
  const requiredFields = form.querySelectorAll("[required]")
  let isValid = true

  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      field.style.borderColor = "#EF4444"
      isValid = false
    } else {
      field.style.borderColor = "#D1D5DB"
    }
  })

  return isValid
}

/**
 * Smooth scroll to element
 */
function scrollToElement(elementId) {
  const element = document.getElementById(elementId)
  if (element) {
    element.scrollIntoView({
      behavior: "smooth",
      block: "start",
    })
  }
}

/**
 * Copy to clipboard
 */
function copyToClipboard(text) {
  if (navigator.clipboard) {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        showAlert("Copied to clipboard!", "success")
      })
      .catch(() => {
        showAlert("Failed to copy", "error")
      })
  } else {
    // Fallback for older browsers
    const textArea = document.createElement("textarea")
    textArea.value = text
    document.body.appendChild(textArea)
    textArea.select()
    try {
      document.execCommand("copy")
      showAlert("Copied to clipboard!", "success")
    } catch (err) {
      showAlert("Failed to copy", "error")
    }
    document.body.removeChild(textArea)
  }
}

/**
 * Format number with commas
 */
function formatNumber(num) {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}

/**
 * Debounce function for search
 */
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

/**
 * Add CSS animations
 */
const style = document.createElement("style")
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .file-preview {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: #F9FAFB;
        border-radius: 8px;
        margin-top: 0.5rem;
    }
    
    .file-preview .file-icon {
        width: 48px;
        height: 48px;
        background: #E7F9F4;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .file-preview .file-icon svg {
        width: 24px;
        height: 24px;
        stroke: #047857;
    }
    
    .file-info p {
        margin: 0;
        font-size: 0.9rem;
    }
    
    .file-info p:first-child {
        font-weight: 500;
    }
`
document.head.appendChild(style)
