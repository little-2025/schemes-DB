/**
 * Admin Panel JavaScript
 */

// Import debounce function or declare it here
function debounce(func, wait) {
  let timeout
  return function (...args) {
    
    clearTimeout(timeout)
    timeout = setTimeout(() => func.apply(this, args), wait)
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initializeAdminFeatures()
  loadDrafts()
  initializeBulkActions()
})

function initializeAdminFeatures() {
  // File upload preview
  const fileInputs = document.querySelectorAll('input[type="file"]')
  fileInputs.forEach((input) => {
    input.addEventListener("change", function () {
      previewFile(this)
    })
  })

  // Form validation
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      if (!validateAdminForm(this)) {
        e.preventDefault()
      }
    })
  })

  // Auto-save drafts (for longer forms)
  const textareas = document.querySelectorAll("textarea")
  textareas.forEach((textarea) => {
    textarea.addEventListener(
      "input",
      debounce(function () {
        saveDraft(this)
      }, 1000),
    )
  })

  // Confirm delete actions
  const deleteLinks = document.querySelectorAll('a[href*="delete"]')
  deleteLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      if (!confirm("Are you sure you want to delete this item? This action cannot be undone.")) {
        e.preventDefault()
      }
    })
  })
}

function validateAdminForm(form) {
  const requiredFields = form.querySelectorAll("[required]")
  let isValid = true

  requiredFields.forEach((field) => {
    if (!field.value.trim()) {
      field.style.borderColor = "#ef4444"
      field.style.backgroundColor = "#fef2f2"
      isValid = false

      // Show error message
      let errorMsg = field.parentNode.querySelector(".error-message")
      if (!errorMsg) {
        errorMsg = document.createElement("small")
        errorMsg.className = "error-message"
        errorMsg.style.color = "#ef4444"
        errorMsg.style.display = "block"
        errorMsg.style.marginTop = "0.25rem"
        field.parentNode.appendChild(errorMsg)
      }
      errorMsg.textContent = "This field is required"
    } else {
      field.style.borderColor = "#d1d5db"
      field.style.backgroundColor = "#ffffff"

      // Remove error message
      const errorMsg = field.parentNode.querySelector(".error-message")
      if (errorMsg) {
        errorMsg.remove()
      }
    }
  })

  return isValid
}

function previewFile(input) {
  const file = input.files[0]
  let preview = input.parentNode.querySelector(".file-preview")

  if (file) {
    const fileName = file.name
    const fileSize = formatFileSize(file.size)
    const fileType = file.type

    if (!preview) {
      preview = document.createElement("div")
      preview.className = "file-preview"
      input.parentNode.appendChild(preview)
    }

    preview.innerHTML = `
            <div class="file-preview-content">
                <div class="file-icon">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14,2 14,8 20,8"/>
                    </svg>
                </div>
                <div class="file-info">
                    <p><strong>${fileName}</strong></p>
                    <p>Size: ${fileSize}</p>
                    <p>Type: ${fileType}</p>
                </div>
                <button type="button" class="remove-file" onclick="removeFilePreview(this)">×</button>
            </div>
        `
    preview.style.display = "block"
  } else if (preview) {
    preview.style.display = "none"
  }
}

function removeFilePreview(button) {
  const preview = button.closest(".file-preview")
  const input = preview.parentNode.querySelector('input[type="file"]')

  input.value = ""
  preview.style.display = "none"
}

function formatFileSize(bytes) {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

function saveDraft(textarea) {
  const formId = textarea.closest("form").id || "default"
  const fieldName = textarea.name
  const value = textarea.value

  if (value.trim()) {
    localStorage.setItem(`draft_${formId}_${fieldName}`, value)
    showDraftSaved(textarea)
  }
}

function loadDrafts() {
  const textareas = document.querySelectorAll("textarea")
  textareas.forEach((textarea) => {
    const formId = textarea.closest("form").id || "default"
    const fieldName = textarea.name
    const draftKey = `draft_${formId}_${fieldName}`
    const draft = localStorage.getItem(draftKey)

    if (draft && !textarea.value.trim()) {
      textarea.value = draft
      showDraftLoaded(textarea)
    }
  })
}

function showDraftSaved(element) {
  let indicator = element.parentNode.querySelector(".draft-indicator")
  if (!indicator) {
    indicator = document.createElement("small")
    indicator.className = "draft-indicator"
    indicator.style.color = "#10b981"
    indicator.style.fontSize = "0.75rem"
    indicator.style.marginTop = "0.25rem"
    indicator.style.display = "block"
    element.parentNode.appendChild(indicator)
  }

  indicator.textContent = "Draft saved"

  setTimeout(() => {
    if (indicator) {
      indicator.textContent = ""
    }
  }, 2000)
}

function showDraftLoaded(element) {
  let indicator = element.parentNode.querySelector(".draft-indicator")
  if (!indicator) {
    indicator = document.createElement("small")
    indicator.className = "draft-indicator"
    indicator.style.color = "#6b7280"
    indicator.style.fontSize = "0.75rem"
    indicator.style.marginTop = "0.25rem"
    indicator.style.display = "block"
    element.parentNode.appendChild(indicator)
  }

  indicator.textContent = "Draft loaded"

  setTimeout(() => {
    if (indicator) {
      indicator.textContent = ""
    }
  }, 3000)
}

function clearDrafts(formId = "default") {
  const keys = Object.keys(localStorage)
  keys.forEach((key) => {
    if (key.startsWith(`draft_${formId}_`)) {
      localStorage.removeItem(key)
    }
  })
}

// Bulk actions for admin tables
function initializeBulkActions() {
  const checkboxes = document.querySelectorAll('input[type="checkbox"][name="bulk_select[]"]')
  const selectAllCheckbox = document.getElementById("select-all")
  const bulkActionSelect = document.getElementById("bulk-action")
  const bulkActionButton = document.getElementById("bulk-action-btn")

  if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener("change", function () {
      checkboxes.forEach((checkbox) => {
        checkbox.checked = this.checked
      })
      updateBulkActionButton()
    })
  }

  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", updateBulkActionButton)
  })

  if (bulkActionButton) {
    bulkActionButton.addEventListener("click", () => {
      const selectedIds = Array.from(checkboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)

      const action = bulkActionSelect.value

      if (selectedIds.length === 0) {
        alert("Please select items to perform bulk action")
        return
      }

      if (!action) {
        alert("Please select an action")
        return
      }

      if (action === "delete") {
        if (!confirm(`Are you sure you want to delete ${selectedIds.length} items?`)) {
          return
        }
      }

      performBulkAction(action, selectedIds)
    })
  }
}

function updateBulkActionButton() {
  const checkboxes = document.querySelectorAll('input[type="checkbox"][name="bulk_select[]"]')
  const bulkActionButton = document.getElementById("bulk-action-btn")
  const selectedCount = Array.from(checkboxes).filter((cb) => cb.checked).length

  if (bulkActionButton) {
    bulkActionButton.disabled = selectedCount === 0
    bulkActionButton.textContent = selectedCount > 0 ? `Apply to ${selectedCount} items` : "Apply Action"
  }
}

function performBulkAction(action, ids) {
  // Show loading state
  const button = document.getElementById("bulk-action-btn")
  const originalText = button.textContent
  button.textContent = "Processing..."
  button.disabled = true

  // In a real implementation, you'd send this to the server
  // For now, we'll simulate the action
  setTimeout(() => {
    alert(`Bulk action "${action}" performed on ${ids.length} items`)
    button.textContent = originalText
    button.disabled = false

    // Reload page to show changes
    window.location.reload()
  }, 1000)
}

// Export functions for global use
window.adminUtils = {
  validateAdminForm,
  previewFile,
  removeFilePreview,
  formatFileSize,
  saveDraft,
  loadDrafts,
  clearDrafts,
  performBulkAction,
}
